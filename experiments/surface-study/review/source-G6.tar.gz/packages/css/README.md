# @kbui/css

All kbui styling, as plain CSS. Components are styled through `kb-` classes and `data-*` attributes, so any renderer that produces the right markup gets the kbui look: React, another framework or hand-written HTML.

## Importing

Most apps import the full stylesheet once at the root. It contains the tokens, a small reset and every component:

```ts
import "@kbui/css/styles.css";
```

Individual files are also available: `@kbui/css/reset.css`, or a single component such as `@kbui/css/components/button.css`. A single component file does not include the tokens, so load those separately.

Plain HTML works as well:

```html
<button class="kb-button" data-variant="secondary" data-size="sm">Cancel</button>
```

## Components

The first line of each stylesheet describes the markup it expects.

| File | Expected markup |
|---|---|
| `button.css` | `.kb-button` with `data-variant` (`primary`, `secondary`, `ghost`, `danger`), `data-size` (`sm`, `md`, `lg`) and `data-disabled` |
| `input.css` | `.kb-input` with `data-size`, `data-invalid` and `data-disabled`, wrapping `-label`, `-control`, `-description` and `-error` parts |
| `dialog.css` | `.kb-dialog-popup` with `-title`, `-description` and `-actions` parts, beside a `.kb-dialog-backdrop`. Both use Base UI's open, starting and ending attributes for animation |

## Build and test

The CSS bundles the token output, so build the tokens first:

```bash
bun run --cwd packages/tokens build
bun run --cwd packages/css build
bun run --cwd packages/css test
```

The tests check that each component file starts with its `Anatomy:` line and styles the root class it names. They fail if component or reset CSS uses a palette color such as `--kb-gray-500` or a raw color such as `#fff`.

[docs/architecture.md](../../docs/architecture.md) describes the contract in full.
