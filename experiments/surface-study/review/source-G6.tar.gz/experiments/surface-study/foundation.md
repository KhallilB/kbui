# Shared foundation · CG-F1

2026-10-23. Binding: `/Users/khallil/proj/kbui/.claude/worktrees/study-catalog-growth`, scratch branch `worktree/study-catalog-growth`, kbui 0.5.0 at `d3e0e832951088ea1ddd14bba3f198ecb0f680b9`. Named archive and every tracked source byte pinned in `source-snapshot.json`. No uncommitted preparation imported. Owner: current session; no independent builders authorized. Owned scope through first checkpoint: `experiments/surface-study/`. Outputs: this brief, coverage/record, directions and review board. Preserved skill goals remain unchanged; old preparation path superseded by this explicit current-main binding.

## Observed catalog and compatibility

Source evidence: `packages/react/src/index.ts`, all three package manifests, `packages/css/src/components/`, `packages/tokens/tokens.json`, `docs/architecture.md`, `docs/tokens.md`, `docs/guides/adding-a-component.md`. Infigraph queried first but returns older Facet-era symbols for this worktree; current tracked files used to resolve stale-index gap.

15 exported components at baseline: Badge, Button, Callout, Card, Dialog, Grid, Input, Menu, Panel, Progress, ScrollArea, Stat, Status, Toolbar, Tooltip. `kb` is utility, not component. All three packages declare 0.5.0; this is current-main source support, not independent verification of a downloadable release. Product/roadmap still describe 13 components/0.4.0: dated documentation undercounts Card/Grid. No milestone changed.

Shared layouts: Grid auto-fit/stack; Panel.Group grouping. Card is semantic article/list-item presentation with no selection or navigation behavior. Menu is actions, Toolbar is arrow-key actions: neither supplies form-value selection or tab-panel semantics. Missing public exports include Select, Checkbox, RadioGroup, Tabs, Table, EmptyState, Stack and Split. Missing shared component is not synonymous with impossible HTML: native controls remain valid baseline routes.

React adapter requires React/react-dom >=19 and uses Base UI 1.9.0. Tokens/CSS work without React when markup honors anatomy. Vue/Svelte/native behavior adapters are not delivered. CSS imported separately; build tokens before CSS before React. SSR/hydration, portal style scope, installation into another app and native platforms are not proven by this board.

## Shared invariants and owners

Tokens own semantic/scale/component values; CSS owns framework-free anatomy; React/Base UI own focus, keyboard, ARIA and interaction wiring. Surface consumer owns fixtures, inventory, prices, assignment policy, ticket eligibility and application state. UI components must not infer these domain rules. Local fixtures are illustrative, not live stock or bookings.

Preserve recognizable controls, visible names, state semantics, keyboard operation, focus visibility/return, error associations, anatomy, typed public APIs and ref forwarding. Do not fork implementation, style private DOM, encode industry vocabulary in core or add meaningless wrappers to inflate catalog. Menu remains action selection; Tabs must represent panels; Checkbox must expose mixed selection. Product operations remain consumer-owned.

## Expressive freedoms and mechanisms

Products may vary type family/scale, color/material, radius, rhythm/density, composition, content/media and appropriate motion. Use public `--kb-*` tokens, caller className and native surface composition. Button radius, Card surface/padding/border, Grid gap/minimum, Input heights, Panel light/rim/shadow and popup tokens are existing seams. Rebind aliases locally when a wrapper overrides their source; portal content must inherit/receive theme explicitly. Light/dark semantic pairs need deliberate values.

Known limits: Button height/padding are literal per size; 120ms button timing remains literal despite motion tokens. No universal typography, breakpoint, density or layout-intent API. Select/Checkbox/Tabs have no shared anatomy, adapter, tokens, docs or tests. Surface CSS may arrange content, but may not conceal new interaction implementations as typography changes. Avoid adding props until observed gap needs them.

## Two route checks

Restrained dispatch ledger: Input, Toolbar, Status and native semantic table are supported. Bulk mixed selection requires native checkbox baseline; missing maintained Checkbox contract is G2 hypothesis. Native table can suffice; no Table abstraction justified yet.

Ambitious printed event program: surface-owned display serif, flat ticket geometry, date rail and editorial whitespace are supported via native composition plus public controls. Tab panels/ticket type selection lack shared Tabs/Select contracts (G3/G1). No clipping control roots into ticket silhouettes. Decorative perforations stay outside focus geometry. Motion kept surface-owned with reduced-motion override.

## Review checklist

Measured checks: source/archive hashes; markup validity/links; actual browser render at 390/768/1440; horizontal overflow; keyboard links/disclosures/focus; contrast of actual text/control pairs; reduced motion. Later implementations require focused Red then unchanged Green, relevant state/keyboard/focus/browser proof, public export/docs/story, root check and story gates. Board is static direction evidence, not working application behavior or conformance proof.

Human judgments pending: task clarity, meaningful distinction, internal cohesion, reading comfort and preference. Compare pairs on composition, typography, density, rhythm, shape, material and motion. Catalogue every workaround with owning layer before proposing core change. Screenshots or agent judgment cannot establish human preference.

## Study selection and slices

Prior evidence: design-product-component-worlds/results.md deferred Table/Tabs/Select; study-kbui-full-run/results.md reports no new core/API. Their aesthetic and behavior evidence does not satisfy updated component-growth objective. Reuse lesson, not historical approvals. Current run uses original three surface families with revised tasks below.

Slice 1 Goals1/2 owns foundation, static visual board and checkpoint pins only; no production behavior, Red/Green N/A. Slice 2 after approval: one surface blueprint/regions/integration at a time; preserve originals. Slice 3 Goal5 review owns observed gap shortlist and bounded component proposals. Slice 4 after second approval: justified core components through generator, docs/stories/TDD, contrasting contexts and fresh region transfer. No commits, push, release, roadmap or consumer adoption implied. Independent-authorship proof remains unavailable without owner-chosen worker route.
