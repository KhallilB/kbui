# Three directions · CG-D2

2026-10-23. Goal 2 binding: current worktree `study-catalog-growth`; source d3e0e832951088ea1ddd14bba3f198ecb0f680b9 / 0.5.0; foundation CG-F1; coverage CG-C2. Surface scope remains Commerce / Operations / Culture. Task refinements below replace no preserved goal text. Current session owns `directions/`, `foundation.md`, `coverage.md`, `record.md`, snapshot and review evidence. No new agents or independent-author claim. Expected output: visual briefs, nine small studies, three chosen concept studies and one comparison board. Inputs: current public catalog, prior study closeouts, foundation and skill references.

Preview from worktree root:

```sh
python3 -m http.server 43427 --bind 127.0.0.1
```

Open `http://127.0.0.1:43427/experiments/surface-study/directions/`. `index.html` and `board.css` are static visual studies; controls illustrated as presentation, live links navigate to challenge rationale and native disclosures expand notes. No application or component behavior claimed. Fictional content avoids production promises. Local CSS lamp illustration needs no external assets, fonts or credentials.

## Core message and selection

A shared system should make real tasks easier across visibly different products. Current 15-component catalog supports basic actions, display and overlays but lacks maintained value selection, mixed selection and panel navigation APIs. Prior studies relied on native controls or local composition and added no shared components. Choose challenges that make these gaps observable without presuming every native element needs a wrapper. Native select, checkbox and semantic table remain valid baselines.

## Commerce · C-05 · Edition / Material Room

User: home worker choosing a task light, uncertain about finish and availability. Primary task: discover Arc lamp, compare two finishes, select one available finish, quantity and price, review before adding to local bag. Core message: make material and purchase consequences legible. Central feeling: considered confidence. Familiar controls: named option field, quantity, price, availability and confirmation; novelty stays in presentation.

Generic route: white product grid, large lifestyle photo, standard side form. Positive direction: one object as a material specimen with immediate configuration beneath. Raw creative material before selection: sample library, ceramic glaze, museum plinth, numbered assembly sheet, domestic warmth plus technical precision; near retail shelf, mid-distance material archive, far anatomy plate.

| Study | Metaphor / system | Risk / usable extract |
|---|---|---|
| C-A familiar/refined | Catalog shelving, sans product grid, white surface, rectangular option rows | Familiar task path; low expressive challenge |
| C-B distinctive/usable, chosen | Material room, serif specimen title, arch, generous whitespace, rounded option field | Image scale may push options down; preserve first useful decision |
| C-C wildcard | Assembly manual, exploded parts, mono numbering, black ground | Looks like instructions; extract numbered finish annotation only |

POV: this should feel like choosing a useful object from a maker's material room. Central tension: tactile warmth + exact specification. Signature moments: arched specimen stage, numbered finish annotation. Weirdness budget 3: custom visual language with ordinary labeled controls.

Typography: Georgia/serif 48–55px title, system sans product facts, mono 11px specimen labels. Material/color: warm ivory #f3ecde, charcoal #332d24, fired-clay illustration #a54b30. Composition: collection navigation above unequal gallery/configuration split; gallery thumbnails left, price/identity and two visible finish cards right, quantity and bag summary beneath. No dropdown finish field. Large labeled choice tiles, round quantity capsule and pill purchase action supply a different component mix from the other surfaces. Rhythm: 24/32px major gaps, 12/16px fact gaps. Shape: arch for display; capsule controls through public radius seam. Motion: proposed 160ms material reveal; no motion needed to understand selected value, instant under reduced motion. No private-selector override or control-root clipping.

G4 hypothesis: a RadioGroup may provide reusable visible single-choice semantics for finish cards. Source has no RadioGroup export/anatomy. Native radios remain comparison baseline; a wrapper without useful shared contract would not qualify. Observable later proof: labeled group, keyboard/disabled/value behavior, error association and contrasting-context use without copied internals. Existing Input/native number can supply quantity; no QuantityStepper addition presumed. Select G1 is now challenged by Operations filters and Culture ticket class. Commerce retains stock, pricing and bag state.

States: default, unavailable finish, stock pending, failed price refresh, bag confirmation, long product title, missing media. Narrow route: gallery stacks before configuration, with identity/price and options grouped; do not fix section height. No external product photography or real stock claims. User preference and comfort remain untested.

## Operations · O-05 · Relay / Dispatch Ledger

User: shift coordinator under time pressure. Primary task: filter review work, select subset, assign together, inspect task without losing bulk scope. Fixture: 12 open tasks, 3 need review; R-104 loading-bay access, R-108 scanner battery, R-112 manifest. Core message: make action scope explicit before mutation. Central feeling: command without alarm. Consumer owns selection scope and assignment policy, including filtered-out selected records; blueprint must define and visibly announce policy before implementation.

Generic route: dashboard metrics and colored task cards. Positive direction: compact evidence ledger, persistent bulk strip, supporting inspector. Raw material: dispatch sheet, proof marks, control desk, route topology, ledger rules, protective clarity plus speed; near task list, mid-distance logistics manifest, far telephone switchboard.

| Study | Metaphor / system | Risk / usable extract |
|---|---|---|
| O-A familiar/refined | Light team list, rounded cards, roomy sans hierarchy | Clear individual tasks, weak bulk scope |
| O-B distinctive/usable, chosen | Dispatch ledger, matte dark plane, mono IDs, ruled rows, stable bulk strip | Dense touch/focus geometry requires browser proof |
| O-C wildcard | Switchboard cables, route diagram, physical toggles | Spatial topology disrupts scanning and keyboard order; keep explicit scope boundary |

POV: this should feel like a precise shift handoff on a dispatch desk. Central tension: urgency + composure. Signatures: scope strip and aligned evidence records. Weirdness budget 2: readable professional workflow, distinctive compression/material.

Typography: 31px semibold sans title, 13–14px task text, 11–12px mono IDs. Color/material: #152b2b matte dark, #e5eeeb text, #d7ec75 action/scope signal, #bdcdc8 secondary. Rhythm: 8/12/16px; no inherited showroom whitespace. Geometry: 3px action radius, native square check boundaries, rules instead of card stacks. Composition: persistent narrow queue navigation beside search/filter header; mixed-selection table and bounded batch strip beside detail/activity inspector; wide list/detail may be consumer grid. Narrow route converts side navigation into a compact top area, table into labeled record summaries and inspector into following content; keeps selection summary visible in flow. No forced fixed pane. Motion proposed 80ms state emphasis, no automatic reordering.

G1 secondary challenge: Select filters task status/assignee in a dense command toolbar, contrasted with Culture ticket class. G2 hypothesis: Checkbox owns checked/mixed/disabled state exposure and keyboard/focus semantics; app owns selected IDs and bulk mutation. No baseline public Checkbox. Native input already provides strong semantics: only observed repeated integration/anatomy/theming need can justify shared component. Test empty/some/all, Space toggle, disabled unchanged, ref, label association and mixed state; second useful context must be selected from actual task needs before delivery, not inserted merely to meet a count. G3 secondary challenge: detail/activity panels reuse same Tabs API at compact scale. Native table retained; no Table abstraction promised.

States: no/some/all selection, filtered-out selection, empty result, stale task, disabled row, assign failure, retry and success announcement. No optimistic assignment rule invented. Risks: small targets, long IDs, ambiguous total versus visible count; target dimensions/focus and scope wording need measured later proof.

## Culture · K-05 · Night School / Printed Program

User: local attendee comparing evenings, cost and access. Primary task: explore 6–8 November program, choose workshop, ticket class and quantity, inspect summary. Fixture: Print after dark, Friday 6 November 2026 at 19:00, Studio 2, Ada Chen; standard $24, student $16 with ID, step-free entrance/materials included; Saturday sound lab sold out. Facts are fiction, not real event/access promises. Core message: help person find an evening that fits. Central feeling: curious anticipation.

Generic route: interchangeable poster cards and date-picker bar. Positive direction: printed program with date spine and detached ticket summary. Raw material: risograph, marginal notes, issue numbers, perforated tickets, radio schedules, bold ink plus practical facts; near venue calendar, mid-distance festival booklet, far broadcast dial.

| Study | Metaphor / system | Risk / usable extract |
|---|---|---|
| K-A familiar/refined | Venue calendar, lilac poster cards, normal sans heading | Predictable scanning, overlaps familiar card discovery |
| K-B distinctive/usable, chosen | Printed program, oversized italic serif, flat ink, date spine, ticket line | Display title can overpower facts; protect time/access/action |
| K-C wildcard | Night frequency, dark broadcast dial, elastic type, neon schedule | Chronology less clear; keep time-based rhythm only |

POV: this should feel like an intimate night-school program printed by its participants. Central tension: expressive invitation + factual access. Signatures: date spine, ticket tear line outside focusable controls. Weirdness budget 3: adventurous typography/material with conventional selection.

Typography: mixed Georgia roman/italic 77–91px masthead, 30–40px event serif, sans facts, mono time/place labels. Material/color: flat vermilion #fa532f, near-black #261b22, cream #fff2df ticket field. Composition: publication masthead spanning issue, mixed roman/italic title and editorial introduction; vertical date spine beside timed event stories; reservation options expand inline inside one event instead of using a page-bottom form. Square ticket band and typographic action contrast with Commerce capsules and Operations flat commands. Rhythm intentionally alternates large display space and tight program facts. Shape: square controls, flat rules; radius 0 via public theme. Motion proposed 160ms emphasis, reduced-motion instant, no flashing or marquee.

G3 hypothesis: Tabs offers panel relationships, selected semantics, arrow navigation, Home/End and documented activation policy. No Tabs export at baseline. Toolbar isn't navigation between associated panels. Native links can be better if dates become routes; that would disprove Tabs for this task. Keep panel navigation in scope only where date content stays local. Shared Select G1 carries ticket class. No checkbox add-on is invented: materials already included in fixture; G2 contrasting-context evidence remains an obligation. Same public APIs should preserve this print identity and Operations density.

States: empty date, loading program, failed schedule, sold-out workshop, ticket validation error, long access note, success summary. Narrow route rotates vertical date spine into horizontal three-date rail, stacks time above event and ticket fields beneath story, grows long titles and avoids horizontal body scroll. Do not hide sold-out state or student condition in hover tooltip. Production booking/payment excluded.

## Convergence and guardrails

Agent design judgment, not measured user preference: chosen B routes give strongest combination of task clarity, specific metaphor, visual range, responsive feasibility and relevant catalog challenge. Familiar routes score better on recognition but weaker on range; wildcard routes add specific ideas but weaken scanning. All three retain ordinary names, focus and state feedback. No claimed user research or external-reference authority.

Concrete references for builders are this board's nine specimens, its CSS values and the source catalog paths above. Proposed motion is written intent, not an implemented component capability. Later blueprints translate approved identities into screens; this stage does not preempt their region boundaries.

Pairwise proof of intended difference: C/O differ in serif versus utility typography, spacious specimen versus dense ledger composition, arches/capsules versus square/rules, 24/32 versus 8/12/16 rhythm. C/K differ in measured versus oversized italic type, specimen/configurator versus chronological program, rounded versus square geometry, regular versus contrasting rhythm. O/K differ in utility versus expressive type, list/detail versus program spine, dense uniform versus editorial contrast rhythm, instrument versus printed material. Human cohesion/distinctiveness/task-clarity review pending.

Goal 5 must reproduce missing behavior, compare native/public routes and propose smallest justified shared component slices. Goal 6 must implement approved additions with public exports, anatomy, token seams, test-first behavior, accessible keyboard/browser proof, docs/stories, two contrasting contexts and fresh transfer. No new component approval is inferred from this direction checkpoint.


## Owner revision · holistic differentiation · CG-D2

Owner requested stronger holistic difference, including component mix and layouts. This is a request for changes at Goal2, not approval of CG-D1. Preserve original packet at `review/preserved/CG-D1.tar.gz`; current packet supersedes its direction design. Source snapshot and shared invariants unchanged.

The first packet repeated a vertical headline/content/selector/action grammar. Current proposal changes the actual representative page grammar, control anatomy and information order. Three landscape studies each use their own arrangement rather than equal narrow cards. Neutral structural diagrams remove palette/wordmarks/illustration and expose composition for comparison. Seven-row component/layout matrix sits beside rationale. These remain direction studies, not Goal3 region blueprints.

| Surface | Dominant component ecosystem | Identity outside color | Different narrow behavior |
|---|---|---|---|
| Commerce C-05.2 | Product gallery/thumbnails, visible finish radios, quantity input, bag/price summary | Gallery/configurator split, arches, large choice tiles, capsule stepper/purchase action, measured serif | Gallery stacks before configuration |
| Operations O-05.2 | Queue navigation, search/filter toolbar, mixed selection, native task table, batch strip, detail/activity tabs, callout | Three-part workspace, compressed rows, square checks, flat commands, sans/mono hierarchy | Rail becomes top navigation, records become labeled summaries, inspector follows |
| Culture K-05.2 | Issue/masthead, date-panel navigation, timed editorial list, ticket disclosure, ticket class and summary | Masthead/date-spine/program grammar, varied type scale, square ticket band and typographic action | Date spine rotates horizontal, event time and ticket fields stack |

Pairwise review must cover structure, dominant mix, control geometry, hierarchy, rhythm and responsive rearrangement. Shared basic controls remain recognizable and may reuse identical semantic APIs. Do not force separate implementations for visual difference or different behavior for equivalent actions. Product-specific combinations stay consumer-owned. No common hero/card/selector/footer-action template may replace these approved distinctions during implementation.

New candidate G4 RadioGroup is only a hypothesis motivated by visible option comparison; no automatic expansion of Goal6 implementation scope. G1 Select now tests Operations/Culture; G2 Checkbox Operations and later contrasting selection context; G3 Tabs Operations/Culture. Any approved component will still require real baseline reproduction, two contrasting contexts and transfer proof. Missing second-context evidence must remain explicit rather than inventing gratuitous controls.

Human judgment: owner found need for stronger holistic separation; revised CG-D2 judgment awaiting review. Automated geometry checks cannot prove preference or meaningful distinctiveness. Recommendation: approve CG-D2 identities/task challenges only after reviewing larger studies, component matrix and neutral structures. Goal3 stays held; Goal5 remains second pause.
