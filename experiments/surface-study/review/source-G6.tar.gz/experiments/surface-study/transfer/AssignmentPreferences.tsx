import { Button, Checkbox, Dialog, RadioGroup, Select } from "@kbui/react";
import { useRef, useState } from "react";
export function AssignmentPreferences() {
  const host = useRef<HTMLDivElement>(null);
  const [team, setTeam] = useState<string | null>("east");
  const [method, setMethod] = useState("automatic");
  const [notify, setNotify] = useState(true);
  const [open, setOpen] = useState(false);
  const [applied, setApplied] = useState(false);
  function changed() {
    setApplied(false);
  }
  return (
    <div ref={host} className="concept operation transfer">
      <header>
        <span>RELAY / WORKSPACE</span>
        <a href="../operations/">Back to dispatch</a>
      </header>
      <section aria-labelledby="preferences-heading" className="preferences-panel">
        <p className="eyebrow">Fresh-region transfer / local fixture</p>
        <h1 id="preferences-heading">Assignment preferences</h1>
        <p>Set defaults for the next dispatch. Changes apply only to this preview.</p>
        <Select
          label="Default team"
          name="team"
          value={team}
          onValueChange={(value) => {
            setTeam(value);
            changed();
          }}
          options={[
            { value: "east", label: "East team" },
            { value: "west", label: "West team" },
            { value: "night", label: "Night team — unavailable", disabled: true },
          ]}
        />
        <RadioGroup
          label="Assignment method"
          name="method"
          value={method}
          onValueChange={(value) => {
            setMethod(value);
            changed();
          }}
        >
          <RadioGroup.Item value="automatic">Automatic assignment</RadioGroup.Item>
          <RadioGroup.Item value="manual">Manual assignment</RadioGroup.Item>
        </RadioGroup>
        <Checkbox
          label="Notify team after assignment"
          checked={notify}
          onCheckedChange={(value) => {
            setNotify(value);
            changed();
          }}
          description="Preview only. No message will be sent."
        />
        <Dialog open={open} onOpenChange={setOpen}>
          <Dialog.Trigger render={<Button />}>Review preferences</Dialog.Trigger>
          <Dialog.Content container={host} className="preferences-dialog">
            <Dialog.Header>
              <Dialog.Title>Review preferences</Dialog.Title>
              <Dialog.Description>
                Check defaults before applying to this local fixture.
              </Dialog.Description>
            </Dialog.Header>
            <Dialog.Body role="region" aria-label="Draft preferences">
              {team === "west" ? "West team" : "East team"} ·{" "}
              {method === "manual" ? "Manual assignment" : "Automatic assignment"} · Notifications{" "}
              {notify ? "on" : "off"}
            </Dialog.Body>
            <Dialog.Footer>
              <Dialog.Actions>
                <Dialog.Close render={<Button variant="secondary" />}>Keep editing</Dialog.Close>
                <Button
                  onClick={() => {
                    setApplied(true);
                    setOpen(false);
                  }}
                >
                  Apply locally
                </Button>
              </Dialog.Actions>
            </Dialog.Footer>
          </Dialog.Content>
        </Dialog>
        {applied && <p role="status">Preferences applied locally.</p>}
      </section>
    </div>
  );
}
