import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { AssignmentPreferences } from "./AssignmentPreferences";

describe("fresh assignment preferences region", () => {
  it("reviews a draft and applies locally only after confirmation", async () => {
    const user = userEvent.setup();
    render(<AssignmentPreferences />);
    await user.click(screen.getByRole("radio", { name: "Manual assignment" }));
    await user.click(screen.getByRole("combobox", { name: "Default team" }));
    await user.click(await screen.findByRole("option", { name: "West team" }));
    await user.click(screen.getByRole("checkbox", { name: "Notify team after assignment" }));
    fireEvent.click(screen.getByRole("button", { name: "Review preferences" }));
    const dialog = within(await screen.findByRole("dialog", { name: "Review preferences" }));
    expect(dialog.getByRole("region", { name: "Draft preferences" })).toHaveTextContent(
      "West team · Manual assignment · Notifications off",
    );
    expect(screen.queryByText("Preferences applied locally.")).not.toBeInTheDocument();
    fireEvent.click(dialog.getByRole("button", { name: "Apply locally" }));
    expect(await screen.findByRole("status")).toHaveTextContent("Preferences applied locally.");
  });
});
