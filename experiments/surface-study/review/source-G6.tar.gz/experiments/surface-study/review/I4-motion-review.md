# Goal 5 I4 — cross-surface motion review

Status: awaiting owner review. Owner requested appropriate transitions across every surface. I3checkpoint documents preserved in preserved/I3-before-motion-review.tar.gz; prior archives remain intact. Shared component delivery/transfer still held.

## Findings and corrections

| Finding | Surface / reproduction | Category | Correction |
|---|---|---|---|
| All dialogs retained150ms while surface controls had different tempos | Open Bag or Reservation review; compare resolved timing | Integration/motion problem | Explicit control/content/overlay roles with one easing family and differentiated surface tempos. |
| Consumer button rule replaced shared background/border/text transitions | Inspect actual Culture button transition before revision: only opacity/transform | Integration/cascade problem | Restore bounded color transitions alongside transform/opacity. Native selection labels use the same control tempo; Operations rail inherits the full button contract. |
| Disclosures and changed content lacked consistent feedback | Expand Operations activity, change inspected task, change Culture date/ticket class | Surface-specific interaction pattern | Short finite opacity/3px settle on disclosure content, inspector heading identity, session/ticket entry and student acknowledgement. Error/success feedback uses the control tempo. |
| Reduced motion had stylesheet rules but no exercised consumer preview path | System preference false in test browser | Evidence gap | Add accessible Reduce motion diagnostic checkbox; test actual resolved suppression and full journeys without mutating OS preferences. OS path remains a separate unexercised obligation. |
| Growing motion overrides duplicated earlier definitions | Read both no-preference blocks | Integration/maintenance problem | Consolidate into one role-based no-preference block and one keyframe definition per effect. |

## Timing and purpose

| Surface | Controls | Content/disclosures | Dialog overlay | Intent |
|---|---:|---:|---:|---|
| Commerce |160ms|180ms|200ms| Calm, tactile selection and object review. |
| Operations |100ms|120ms|140ms reserved role; no dialog currently used| Fast, precise task work. Selection semantics update immediately; records do not fly or reorder through animation. |
| Culture |140ms|160ms|180ms| Brief editorial reveal for session and ticket changes. |

All use cubic-bezier(.2,.7,.2,1). Dialogs travel6px with subtle.985scale and opacity on entry/exit. Press feedback travels1px. Content moves3px at most; gallery image changes fade. Focus rings and checked/disabled/error semantics remain immediate. Native select popup motion stays browser/OS-owned. Disclosures reveal their content briefly when opened, close immediately, and do not animate height.

Motion is finite, has no arbitrary action delay, and uses no timers, perpetual shimmer, scroll animation, animation library, blanket will-change promotion, backdrop blur, shadow animation or width/height animation. Small control color transitions are bounded paint work. Larger movement uses opacity/transform. This follows [web.dev performance guidance](https://web.dev/articles/animations-and-performance); media preference handling follows [W3C C39](https://www.w3.org/WAI/WCAG22/Techniques/css/C39.html).

## Reduced motion

Default mode follows system preference. Reduce motion can request less movement through the preview toolbar; it never forces motion against the OS preference. In reduced preview mode, computed control/dialog transitions are none, element animations are none, press travel is removed, and dialogs keep their centered transform through open/close states. Text, selection and totals remain available immediately. Drafts survive changing the checkbox. Override resets when the preview reloads; system preference remains independent. No OS setting changed.

## Contract, ownership and Red/Green

Fixture state and rules remain with their owning screens. CSS consumes current DOM identity/expanded/disabled state; it does not own selection, quantity or capacity. TaskInspector keys its heading by task identity for change feedback while the native disclosure and surrounding state remain mounted. Preview motion preference owns only an HTML data attribute, removes it on unmount, and is outside product task controls. Public core API and original163tracked source files remain unchanged; local motion variables are study evidence for a future documented shared seam.

Three focused assertions failed before implementation: default/system versus preview reduce toggling, cleanup, and product draft preservation. Initial accessible description accidentally entered the checkbox name; implementation corrected the label/description boundary without weakening tests.46tests across6files now pass. CSS-only timing/cascade changes use prior computed-style failure evidence and browser checks rather than manufactured unit assertions.

## Checks actually run

- Production study build, strict study TypeScript and root `bun run check`; logs retained. Lint warnings remain.
-46tests across6files, including all existing fixture and delivery tests.
-12normal/reduced primary journeys across Commerce/Operations/Culture at390/1440CSSpx: gallery/quantity/bag review, select/inspect/disclose/assign, student acknowledgement/reservation review. No horizontal overflow; correct totals and focus return. Resolved control/dialog timing matches roles; reduced transition and animation suppression verified.
-36state/mode cases at390CSSpx =3surfaces×6states×2modes: no overflow, no infinite animation iterations, reduced controls have zero transition durations and authored animations resolve to none.
-6final desktop primary-journey replays after consolidation confirm all button properties, dialog timing, focus and actual preference mode. Source-only getAnimations was unsupported by the read-only browser DOM wrapper; computed styles were used instead. No active-animation lifecycle claim made from that failed probe.
-6ready accessibility scans, normal/reduced across3surfaces:0violations and0incomplete. Prior I3dialog contrast uncertainty remains open; this pass does not clear it.
-6local frame samples,120intervals each, during primary interactions: p95 8.8–9.3ms, max9.4ms,0intervals above1.5×median. Browser scheduler evidence only; no universal60/120/144Hz, compositor, physical display, CPU throttling or old-computer performance claim.

## Remaining limits and review

Actual OS preference switching, forced colors, assistive technology, native zoom, other engines and physical hardware remain untested. The new preview override exercises resolved motion suppression, not the W3C OS-switch test procedure. I3open-dialog contrast uncertainty and shared Menu/Tooltip portal-theme transfer remain open. Exact-head local review gate cannot attest untracked experiment bytes and remains withheld; no commit/push created.

Review each live surface in normal and Reduce motion modes, including rapid selection and close/reopen. Approve I4and agreed shared follow-through, request changes or reject. Goal6must formalize approved public motion/elevation/composition seams, perform regression/transfer and record closeout; these local CSS variables are not silently claimed as delivered shared APIs.
