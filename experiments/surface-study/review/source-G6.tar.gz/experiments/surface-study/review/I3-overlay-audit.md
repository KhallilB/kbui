# Goal 5 I3 — overlay audit and revision

Status: awaiting owner review. Owner requested all-popover audit after I2; this checkpoint revision does not approve unrelated shared catalog additions. I2 board, manifest and record preserved in preserved/I2-before-overlay-review.tar.gz; integration-I2.tar.gz remains intact.

## Inventory and findings

| Surface / primitive | Reproduction and evidence | Cause category | Correction / disposition |
|---|---|---|---|
| Commerce / Bag review Dialog | Add1–6units; dialog previously showed four undifferentiated text blocks | Surface-specific pattern | Packing-slip hierarchy: labelled item section, quantity/unit price/dispatch, distinct total, preview disclosure, close control and action footer. Warm paper and soft layered shadow. |
| Culture / Reservation review Dialog | Review standard/student/free tickets; date/time/venue absent | Surface-specific pattern | Printed ticket: session/date/time/venue, ticket class/quantity, conditional student/free note, total band and square offset depth. |
| Both Dialog footers | Composed semantic footer inherited global40px top margin and border | Integration/layout problem | Scoped margin/border/width reset. Browser confirms0px resolved margin. |
| Culture / long session review | Long program heading shortened on review | Integration/content mismatch | One fixture title now feeds both program and dialog. Focused assertion failed, then passed. |
| Preview / cached CSS | New markup rendered with old CSS: close static, padding0, no shadow | Integration/delivery problem | Build computes script/CSS hashes into all three entry URLs; regression failed on stale URL then passed. |
| Operations / Task status native select | Switch Needs review to All open tasks | Native platform UI | Browser selection verified; correct12-task heading. Native popup appearance belongs to browser/OS; maintained Select remains proposed Goal6 work. |
| Culture / Ticket class native select | Choose Student | Native platform UI | Student acknowledgement appears; native semantics retained. |
| Operations activity / Culture ticket disclosure | Expand activity or ticket options | Inline disclosure, not floating overlay | Existing semantic details/summary retained; no unnecessary modal added. |
| Shared Menu | Catalog source only, unused in these surfaces | Existing shared primitive | Already has popup surface/border/shadow, highlighted/focus/disabled states and reduced-motion override. No runtime cross-surface claim. |
| Shared Tooltip | Catalog source only, unused in these surfaces | Existing shared primitive | Already has compact text hierarchy and popup elevation; keep informational scope rather than turning hints into cards. No runtime cross-surface claim. |
| Shared Dialog | Source anatomy compared with Menu/Tooltip | kbui-core limitation / candidate | Dialog lacks their public popup-elevation treatment; consumer composition proves hierarchy without changing core. Propose coherent dialog surface/elevation/motion tokens in Goal6. |
| Shared Menu/Tooltip portal theme | Source uses default body portal; Dialog exposes container | Shared API risk, source-derived | Nested consumer theme inheritance needs a dedicated transfer check. Menu permits a className but no container; Tooltip exposes neither container nor popup class. No untested portal behavior declared fixed. |

## Design direction

Use existing approved identities. Commerce feels like an orderly packing slip on warm paper: line item, concise facts, price anchor, calm rounded perimeter. Culture feels like a printed admission ticket: issue marker, session stub, dashed division, cream stock, square edge and ink offset. Familiar modal interaction remains consistent; depth distinguishes foreground from the dimmed application. A generic shadow-only restyle and decorative glossy effects were considered; content-led grouping gives depth a task purpose. No new illustration, looping animation or backdrop blur introduced. Existing transform/opacity transition and reduced-motion behavior retained.

## Contract and ownership

Fixture screens own quantity, price, event identity and student acknowledgement. Region components compose public Dialog.Title/Description/Close/Actions, preserving accessible names/descriptions and controlled state. Themes own material, rhythm and elevation. Runtime owns diagnostics and cache versioning. No shared component API or core source changed; catalog remains15. No purchase/booking/persistence added. Infigraph returned no matching study symbols, so current worktree source was read directly.

## Verification

-43tests across5files pass. Initial overlay assertions2failed; cache URL assertion1failed; long-title consistency assertion1failed. Same assertions pass after their fixes. Logs in evidence-I3/.
- Study production build and strict TypeScript check; root check log supplied. Static visual changes use screenshot/computed-style evidence, not a manufactured unit Red.
-16open-dialog cases:2surfaces×4actual widths320/390/768/1440×2heights480/900. All remain within viewport, have no horizontal overflow, trap Tab within dialog, and restore originating focus after Escape. Short windows scroll within popup.
-8Culture variants at390/1440: long title, student, free admission and6tickets. No recorded overflow or axe violations; closeX preserves draft and restores focus.
-2outside-click dismissals restore origin focus. Native Operations status and Culture ticket-class selection exercised; Operations activity expands with semantic disclosure.
-24open-dialog axe scans:0recorded violations. 13scans retain color-contrast incomplete results because axe reports possible partial overlap. Screenshots/computed geometry inspected; authored opaque text pairs measure6.40–15.07:1. This narrow manual contrast check does not clear the automated uncertainty or establish conformance. See overlay-cases.json, overlay-variants.json and authored-contrast.json.
- Current shared Menu/Tooltip review is source-level only; no claim they were exercised in study screens or that their portal/theme risk is fixed.
- New audit shortcut Alt+Shift+A runs local axe against the open dialog while modal focus correctly makes the diagnostic toolbar inert. Diagnostic wiring uses real browser execution as its test-first exception; runtime page unload owns listener lifetime.

## Review gate and limits

Local review-only gate invoked again, refused because no open round exists for scratch branch. Candidate remains untracked and cannot be attested by original source HEAD; outcome withheld, not clean. No commit/push invented to satisfy it. Same-session visual judgment only. OS reduced motion, forced colors, screen reader, native zoom, other engines and physical hardware remain untested; prior I2frame/state metrics are historical evidence, not new I3measurements.

## Recommendation

Review I3overlay hierarchy and depth, then approve agreed Goal6 shared additions and transfer, request changes or reject. Extend proposed timing work to include a consistent Dialog elevation/surface seam and portal-theme transfer evidence. Select/Checkbox/RadioGroup proposals remain pending. No adoption, release or milestone change implied.
