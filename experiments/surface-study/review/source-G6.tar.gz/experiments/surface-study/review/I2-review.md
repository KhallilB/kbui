# Goal 5 revision I2 — state, geometry and interaction corrections

Status: awaiting owner review. Replaces I1 preview and its open surface findings. Goal 6 shared component additions and transfer remain held. Owner requested these checkpoint revisions; no commits, release, production adoption or milestone change.

## What changed and why

- Commerce dialog used `--kb-dialog-radius:999px` on a roughly262px-high popup. Curved corners consumed its content area. Consumer theme now uses20px corners; dialog width/padding/maximum dynamic viewport height protect text and actions. Culture retains square corners. Escape returns to originating action after close transition.
- Chalk had the same solid boundary, transparent fill and opacity1 as the available finish. Native disabled semantics now have an explicit Unavailable badge, dashed boundary, patterned swatch, differentiated fill and accessible return-date description. Selected finish and gallery photo have persistent selected treatments; selected photo keeps contrast on hover/focus.
- Product name and price now share a text baseline. Culture ticket controls align their labels and inputs independently of helper text. Operations search/filter controls retain a common lower edge; bulk strip wraps with explicit gaps. Three original page grammars remain distinct.
- Fake lamp shapes replaced by locally served responsive stock photography. Real studio/detail views replace false material/room claims. Photo failure retains product controls and offers retry. Photo by sue hughes, [source](https://unsplash.com/photos/brown-and-clear-glass-table-lamp-_QcxiSUIwbE), [Unsplash license](https://unsplash.com/license). It illustrates lighting, not the fixture SKU; caption states this. Operations remains a functional ledger and Culture a typographic publication; no decorative photos inserted into task controls.
- All three surfaces now have contextual loading, empty and error states: named heading, explanatory copy, stable geometry, one explicit recovery action and local-preview disclosure. Loading is intentionally inspectable with a static skeleton, rather than an endless spinner. Error copy describes the corresponding domain outcome. Ready, long-content, action-failure and successful review/assignment flows remain available.
- Operations bulk actions explain why disabled, locked records remain labelled, filter title/count tracks actual results. Assignment success now focuses its announced result because the submit button becomes disabled. Clearing selection clears obsolete failure. Tests exposed both defects before repair.
- Culture invalid quantity focuses the invalid field and marks it invalid. Sold-out sessions expose their unavailable status and offer another date through the date spine. Student acknowledgement, free event, draft retention and retry remain tested.
- Motion uses finite opacity/transform feedback and short surface timings: Commerce160ms, Operations100ms, Culture140ms. Dialog retains shared150ms transition. Reduced-motion rules remove transitions/animations, and new motion only activates under no-preference. No shimmer loops, scroll listeners, parallax, spring loops or layout-property animation added. Guidance: [web.dev animation performance](https://web.dev/articles/animations-and-performance), [W3C reduced-motion technique](https://www.w3.org/WAI/WCAG22/Techniques/css/C39.html).
- Preview shipped development React and eagerly loaded axe. Assertion failed on development-only diagnostic, then passed with production React. Axe now loads only for explicit audit. Main entry1407732→464030bytes,67.0% smaller before compression; a small shared chunk also loads. This is a delivery-size measurement, not a startup-time or universal-hardware claim. Build definition follows [Bun’s documented define option](https://bun.sh/docs/bundler#define).

## Ownership and test contract

Surface fixtures own availability, capacity, selection, recovery and draft state. kbui owns public Button/Input/Dialog/Status behavior. Consumer themes own geometry/identity. Runtime harness owns static preview building and diagnostics. No domain policy moved into shared primitives, no backend or paid service added, core catalog remains15. Infigraph search returned no study symbols; current worktree files were inspected directly instead of using stale root-index symbols.

Red evidence: initial16assertion failures across contextual states, unavailable finish, real gallery and dynamic heading; Culturefocus3failures; Operationsbulk guidance1failure; successfocus/staleerror2failures; productionReact1failure. Each changed behavior reached unchanged Green assertions. Current39tests include photo-error recovery. Static visual/style changes use before/after computed geometry and native screenshots instead of a manufactured unit Red. Frame sampler is diagnostic-only; its exception is browser validation and120sample bounded runs, not a domain-behavior TDD claim.

## State and interaction coverage

| State | Commerce | Operations | Culture |
|---|---|---|---|
| Ready / selected | Finish + real photo choice | Visible selection + mixed checkbox + inspector | Date + session + ticket class |
| Disabled / unavailable | Chalk reason + native disabled | Locked task + disabled bulk guidance | Sold-out session has no booking action |
| Loading | Product details + paused skeleton | Team tasks + paused skeleton | Program sessions + paused skeleton |
| Empty | Explain missing sample, explore data | Explain missing sample, explore data | Explain missing sample, explore data |
| Error / retry | No order, explicit retry | No reassignment, explicit retry | No booking/payment, explicit retry |
| Invalid input | Whole quantity1–6 + focus | Empty search + clear recovery | Capacity + student ID + quantity focus |
| Action failure | Retain quantity, retry bag preview | Retain selection, retry assignment | Retain ticket draft, retry review |
| Success / dismissal | Review total, Escape restores focus | Exact assigned count, focus result | Review tickets/total, Escape restores focus |
| Long / reflow | Product title | Task title | Session title |

## Checks actually run

- Study build + strict study TypeScript check.
-39tests across5files, with assertion Red evidence preserved.
- Root `bun run check` (build/lint/type/tests/package): final log linked from board after completion. Lint warnings remain; no warning-free claim.
- Final production layout sweep:90cases =3surfaces×6states×5actual widths320/390/768/1440/1920; no horizontal overflow or broken images. `evidence-I2/geometry-production.json`.
-36state scans at390/1440,6triggered-failure scans and6ready repeats:48axe scans,0violations,0incomplete. Most state scans preceded production-mode build; production ready scans and all90production layouts repeated afterward. `accessibility-scans.json` records each run explicitly.
-6keyboard failure/retry journeys at390/1440,4dialog bounds checks, final6focus recoveries. Production ready primary tasks repeated. Culture first immediate Escape focus reading caught ending transition; final explicit focused-action wait proves restoration. Earlier raw observation retained rather than represented as final success.
- Local production frame sampler:120intervals/surface during primary interactions. Median10ms; p95Commerce10.6ms / Operations10.5ms / Culture10.8ms, max11.1ms;0intervals above1.5×median. This browser’s scheduler report is only local frame pacing, not compositor/presentation profiling or support proof for60/120/144Hz hardware.
- Original163tracked source members remain pinned and unchanged; no shared core source edited. I1 remains preserved in integration-I1.tar.gz and preserved/I1-before-owner-changes.tar.gz.

## Local review loop outcome and open obligations

`review-loop-local review-only` invoked. Exact-head gate refused: `no open round for branch worktree/study-catalog-growth; nothing to do`. The study is untracked work against the original source HEAD; a commit-bound PR gate cannot attest these candidate bytes. No PR number invented, no commit made to manufacture gate evidence. Exact candidate manifest/archive provides reproducibility but does not replace that gate. Outcome: withheld, not clean. Independent reviewer, exact-head review obligations, class closure and calibration remain unproven. No commit/push performed.

Same-session source probes covered12questions across geometry/cascade, state semantics, keyboard/lifecycle and delivery/performance: dialog corner/padding resolution; title/price baseline; helper-text alignment; mobile overflow; disabled native semantics and visual distinction; selected hover contrast; draft retention; locked selection; stale-error clearance; focus after disable/close; production bundle; scanner/motion/image costs. Confirmed defects repaired above; these probes are self-review, not independent gate evidence.

## Remaining limits and next review

OS reduced-motion, forced-colors presentation, screen reader, native browser zoom, CPU/network throttling, other browser engines and physical refresh rates were not exercised. CSS rules and native semantics were inspected; prior166shared story tests remain I1 evidence, not rerun I2 evidence. Local audits do not establish accessibility conformance, human preference, final product content, real capacity/order safety or broad hardware performance.

Review I2’s distinct screens, state hierarchy, disabled cues, geometry, photography and motion. Approval would then release only agreed Goal6shared additions (Select/Checkbox/RadioGroup plus timing token), regression and fresh-region transfer. Existing F1title and F2caption are resolved within this owner-requested checkpoint revision. Shared API proposals remain in findings.md; no new shared component silently implemented.
