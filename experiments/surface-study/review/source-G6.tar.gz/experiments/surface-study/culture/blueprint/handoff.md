# culture whole-screen blueprint B1

Binding: current study worktree; source d3e0e83 / kbui0.5.0; foundationCG-F1; approved directionK-05.2 / CG-D2; approval review/goal2-approval.json. Current session owns shell/theme/gutters. Same-session region author; independent authorship not demonstrated. Owned paths culture/Screen.tsx, blueprint/, regions/. Inputs source-snapshot.json, directions/briefs.md and reference.html. Output three modules, tests, region handoffs, isolation previews and preserved original archive.

## Whole-screen reference

reference.html with theme.css and shared/direction-baseline.css fixes composition/type/material. Preview via existing43427server: /experiments/surface-study/culture/blueprint/reference.html. Inspect390/768/1440. Final app /experiments/surface-study/culture/; region query ?region=1|2|3; fixture state query ?state=ready|loading|empty|error|long|action-error. Screenshots in blueprint/evidence/. Blueprint illustrative controls have no application behavior.

Layout: Publication masthead then date spine and time-led event stories; ticket fields appear inline beneath chosen story in native disclosure. Native radio date filter stands in for missing Tabs; native ticket select stands in for shared Select. Public Input/Button/Dialog/Status integrate actions and feedback.

Narrow: Date spine rotates horizontal, time above story, ticket fields stack below. Native date group arrow behavior follows HTML; disclosure keyboard works, reservation dialog restores trigger focus. Sold-out action disabled and labeled.

## Behavior ownership and seams

ProgramNavigation receives selected date and emits selection. EventProgram displays date-filtered fixture events and emits event choice. TicketReservation receives event and quantity/class drafts; emits form edits and reserve; validates positive integer quantity against fixture capacity and student ID acknowledgement. Shell coordinates chosen event and draft/reservation/errors, derives price from class. Date changes select first available event, clear validation and prior confirmation; no booking/payment/persistence.

Inputs are local typed fixtures. No backend, persistent storage, timers or money movement. Field syntax/selection semantics remain delivery/UI; fixture stock/eligibility and use-case mutation stay in surface shell. Shared kbui core unchanged. Unsupported semantics must stay in gap log, not copied core.

## Three region briefs

1. **ProgramNavigation** — first region described in contract above. File regions/ProgramNavigation.tsx; one writer. Use only region-owned composition and existing public components. Receives shell callbacks/state, never writes neighbor state. Relevant ready/long and fixture failure boundary states. Keep shell/theme immutable during region work.
2. **EventProgram** — second region described above. File regions/EventProgram.tsx; same explicit writer, consumes shared theme/reference. Owns focusable form/record controls and emits callbacks. Empty/loading/error/disabled/long states must be available in fixture harness. No layout decisions outside allocated region.
3. **TicketReservation** — third region described above. File regions/TicketReservation.tsx; callbacks/state supplied by shell. Preserve named adjacent relationships, inline feedback and applicable dialog focus semantics. Include action-error/retry and long-content proof.

Each region gets available width from owning shell grid, min-inline-size0, no body-scroll forcing or fixed content heights. Preview isolation preserves theme/shell allocation; neighboring regions omitted and explicitly labeled isolation. Full reference shared through this file. Region tests may be integrated at owning surface seam where state crosses regions.

## Acceptance and test list

Primary journey, unavailable/disabled choice, invalid quantity/selection, error retaining draft, retry, no/some/all or sold-out as applicable; external state boundaries loading/empty/error have explicit manual fixture recovery. Tests first, then implementation. Browser keyboard/focus, default+long+failure at390/768/1440; public package behavior reused. Root bun run check and shared story gates required for Goal5 handoff. Unknown: native AT, independent authorship and human cohesion until owner review.
