export type EventFixture = {
  id: string;
  day: string;
  title: string;
  time: string;
  end: string;
  kind: string;
  room: string;
  description: string;
  price: number;
  capacity: number;
};
export const events: EventFixture[] = [
  {
    id: "print",
    day: "06",
    title: "Print after dark",
    time: "19:00",
    end: "20:30",
    kind: "Workshop",
    room: "Studio 2",
    description:
      "Two-colour risograph with Ada Chen. Leave with ink on your hands and a small edition of your own.",
    price: 24,
    capacity: 6,
  },
  {
    id: "sound",
    day: "06",
    title: "A room for slow sound",
    time: "21:00",
    end: "22:00",
    kind: "Listening session",
    room: "Main room",
    description: "Field recordings and shared listening with Imani Cole.",
    price: 0,
    capacity: 6,
  },
  {
    id: "lab",
    day: "07",
    title: "Sound lab",
    time: "20:00",
    end: "22:00",
    kind: "Workshop",
    room: "Main room",
    description: "An evening of collaborative listening.",
    price: 24,
    capacity: 0,
  },
  {
    id: "repair",
    day: "08",
    title: "Repair and reimagine",
    time: "18:00",
    end: "20:00",
    kind: "Open studio",
    room: "Studio 2",
    description:
      "Bring an object and explore another use. Step-free entrance; contact host for other access needs.",
    price: 24,
    capacity: 6,
  },
];
