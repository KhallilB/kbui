import { RadioGroup } from "@kbui/react";
import type { JSX } from "react";
export function ProgramNavigation({
  day,
  onDay,
}: {
  day: string;
  onDay: (v: string) => void;
}): JSX.Element {
  return (
    <RadioGroup
      className="date-spine"
      label="Program date"
      visuallyHidden
      value={day}
      onValueChange={onDay}
      name="program-date"
    >
      {[
        ["06", "Friday", "2 sessions"],
        ["07", "Saturday", "1 sold out"],
        ["08", "Sunday", "1 session"],
      ].map(([value, name, note]) => (
        <RadioGroup.Item
          key={value}
          className={`program-date ${day === value ? "current" : ""}`}
          controlClassName="program-date-control"
          value={value ?? ""}
        >
          <b>{value}</b> <span>{name}</span> <small>{note}</small>
        </RadioGroup.Item>
      ))}
    </RadioGroup>
  );
}
