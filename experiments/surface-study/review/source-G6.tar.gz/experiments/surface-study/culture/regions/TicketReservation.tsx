import { Button, Checkbox, Dialog, Input, Select } from "@kbui/react";
import type { FormEvent, JSX, RefObject } from "react";
import type { EventFixture } from "../types";

type Props = {
  event: EventFixture;
  quantity: string;
  ticketClass: string;
  studentId: boolean;
  error: string;
  total: number;
  open: boolean;
  onOpen: (v: boolean) => void;
  onQuantity: (v: string) => void;
  onClass: (v: string) => void;
  onStudent: (v: boolean) => void;
  onSubmit: (e: FormEvent<HTMLFormElement>) => void;
  container: HTMLDivElement | null;
  trigger: RefObject<HTMLButtonElement | null>;
};
export function TicketReservation({
  event,
  quantity,
  ticketClass,
  studentId,
  error,
  total,
  open,
  onOpen,
  onQuantity,
  onClass,
  onStudent,
  onSubmit,
  container,
  trigger,
}: Props): JSX.Element {
  return (
    <details key={event.id} className="ticket-preview" open>
      <summary>Ticket options for {event.title}</summary>
      <form noValidate onSubmit={onSubmit}>
        <div className="ticket-fields">
          <Select
            className="native-field ticket-class"
            label="Ticket class"
            value={ticketClass}
            onValueChange={(next) => {
              if (next !== null) onClass(next);
            }}
            options={[
              { value: "standard", label: `Standard · $${event.price}` },
              ...(event.price > 0 ? [{ value: "student", label: "Student · $16 with ID" }] : []),
            ]}
          />

          <Input
            label="Ticket quantity"
            inputMode="numeric"
            value={quantity}
            onValueChange={onQuantity}
            description={`${event.capacity} places available in fixture.`}
            aria-invalid={error.startsWith("Choose a whole quantity") || undefined}
            aria-describedby={error ? "reservation-error" : undefined}
          />
          <div className="ticket-total">
            <small>Draft total</small>
            <b>${total}</b>
          </div>
        </div>
        {ticketClass === "student" && (
          <Checkbox
            className="student-check"
            label="I will bring student ID"
            checked={studentId}
            onCheckedChange={onStudent}
          />
        )}
        {error && (
          <p id="reservation-error" className="inline-error" role="alert">
            {error}
          </p>
        )}
        <Button ref={trigger} type="submit" className="ticket-action" variant="ghost">
          Review reservation
        </Button>
        <p className="fixture-facts">Local capacity fixture · no payment or reservation made.</p>
      </form>
      <Dialog
        open={open}
        onOpenChange={onOpen}
        onOpenChangeComplete={(isOpen) => {
          if (!isOpen) trigger.current?.focus();
        }}
      >
        <Dialog.Content container={container} className="study-dialog reservation-dialog">
          <Dialog.Header className="overlay-header">
            <span className="eyebrow">NIGHT SCHOOL / ISSUE 07</span>
            <Dialog.Title className="overlay-title">Reservation review</Dialog.Title>
            <Dialog.Description className="overlay-description">
              Fixture preview only. No booking or payment.
            </Dialog.Description>
            <Dialog.Close
              render={<Button variant="ghost" />}
              className="overlay-close"
              aria-label="Close reservation review"
            >
              <span aria-hidden="true">×</span>
            </Dialog.Close>
          </Dialog.Header>
          <Dialog.Body
            className="overlay-body overlay-ticket"
            role="region"
            aria-label="Session details"
          >
            <span className="eyebrow">{event.kind} / OAKLAND</span>
            <h3>{event.title}</h3>
            <dl className="overlay-facts">
              <div>
                <dt>Date</dt>
                <dd>{event.day} November 2026</dd>
              </div>
              <div>
                <dt>Time</dt>
                <dd>
                  {event.time}–{event.end}
                </dd>
              </div>
              <div>
                <dt>Venue</dt>
                <dd>{event.room}</dd>
              </div>
            </dl>
            <p className="ticket-summary">
              {quantity} {ticketClass} tickets · ${total}
            </p>
            <p className="overlay-note">
              {ticketClass === "student"
                ? "Bring student ID for the student ticket rate."
                : event.price === 0
                  ? "Free admission · ticket preview still required."
                  : "Materials included · step-free entrance."}
            </p>
          </Dialog.Body>
          <div className="overlay-total">
            <span>Reservation total</span>
            <strong>${total}</strong>
          </div>
          <Dialog.Footer className="overlay-footer">
            <p className="overlay-note">
              Your ticket draft is retained when you return to the program.
            </p>
            <Dialog.Actions className="overlay-actions">
              <Dialog.Close render={<Button />}>Back to program</Dialog.Close>
            </Dialog.Actions>
          </Dialog.Footer>
        </Dialog.Content>
      </Dialog>
    </details>
  );
}
