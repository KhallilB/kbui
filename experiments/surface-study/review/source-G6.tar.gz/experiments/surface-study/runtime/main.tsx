import { createRoot } from "react-dom/client";
import { CommerceScreen } from "../commerce/Screen";
import { CultureScreen } from "../culture/Screen";
import { OperationsScreen } from "../operations/Screen";
import { AssignmentPreferences } from "../transfer/AssignmentPreferences";
import type { Scenario } from "./FixtureState";
import { MotionControl } from "./MotionControl";

const host = document.getElementById("app");
if (!host) throw new Error("Missing application host");
const params = new URLSearchParams(location.search);
const scenarios: Scenario[] = ["ready", "loading", "empty", "error", "long", "action-error"];
const value = params.get("state");
const scenario = scenarios.find((s) => s === value) ?? "ready";
const region = ["1", "2", "3"].includes(params.get("region") ?? "")
  ? (params.get("region") ?? "all")
  : "all";
function navigate(key: string, next: string): void {
  const url = new URL(location.href);
  url.searchParams.set(key, next);
  location.href = url.href;
}
async function audit(): Promise<void> {
  const { default: axe } = await import("axe-core");
  const result = await axe.run(
    document.querySelector(".app-main [role=dialog]") ??
      document.querySelector(".app-main") ??
      document,
    {
      runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa"] },
    },
  );
  const output = document.getElementById("audit-result");
  if (output)
    output.textContent = JSON.stringify(
      {
        violations: result.violations.map((item) => ({
          id: item.id,
          impact: item.impact,
          nodes: item.nodes.map((node) => ({ target: node.target, summary: node.failureSummary })),
        })),
        incomplete: result.incomplete.map((item) => item.id),
        incompleteDetails: result.incomplete.map((item) => ({
          id: item.id,
          nodes: item.nodes.map((node) => ({ target: node.target, summary: node.failureSummary })),
        })),
      },
      null,
      2,
    );
}
// Keep diagnostic scan reachable while modal focus makes the toolbar inert.
document.addEventListener("keydown", (event) => {
  if (event.altKey && event.shiftKey && event.code === "KeyA") {
    event.preventDefault();
    void audit();
  }
});
async function measureFrames(): Promise<void> {
  const output = document.getElementById("performance-result");
  const control = document.getElementById("measure-frames") as HTMLButtonElement | null;
  if (!output || !control) return;
  control.disabled = true;
  output.textContent = "Sampling 120 frames. Try the controls while this runs.";
  const intervals: number[] = [];
  let previous = 0;
  const started = performance.now();
  function frame(now: number): void {
    if (document.hidden) {
      output!.textContent = "Sampling stopped: tab is hidden. Keep preview visible and retry.";
      control!.disabled = false;
      return;
    }
    if (previous) intervals.push(now - previous);
    previous = now;
    if (intervals.length < 120 && now - started < 5000) {
      requestAnimationFrame(frame);
      return;
    }
    const sorted = [...intervals].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)] ?? 0;
    output!.textContent = JSON.stringify(
      {
        samples: sorted.length,
        medianMs: +median.toFixed(2),
        p95Ms: +(sorted[Math.floor(sorted.length * 0.95)] ?? 0).toFixed(2),
        maxMs: +(sorted.at(-1) ?? 0).toFixed(2),
        intervalsAbove1_5xMedian: sorted.filter((x) => x > median * 1.5).length,
        reducedMotion: matchMedia("(prefers-reduced-motion: reduce)").matches,
        previewReducedMotion: document.documentElement.dataset.studyMotion === "reduce",
        scope: "Local browser frame pacing only; not a hardware or refresh-rate guarantee.",
      },
      null,
      2,
    );
    control!.disabled = false;
  }
  requestAnimationFrame(frame);
}
const Surface =
  host.dataset.surface === "transfer"
    ? AssignmentPreferences
    : host.dataset.surface === "operations"
      ? OperationsScreen
      : host.dataset.surface === "culture"
        ? CultureScreen
        : CommerceScreen;
createRoot(host).render(
  <>
    <nav className="diagnostics" aria-label="Study controls">
      <a href="../review/">All surfaces / review</a>
      <span>Local fixtures · no persistence</span>
      <MotionControl />
      <label>
        State{" "}
        <select value={scenario} onChange={(e) => navigate("state", e.target.value)}>
          {scenarios.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </label>
      <label>
        Region{" "}
        <select value={region} onChange={(e) => navigate("region", e.target.value)}>
          {["all", "1", "2", "3"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </label>
    </nav>
    {region !== "all" && (
      <p className="isolation-notice">
        Region {region} isolation · shell theme retained; required state/form host may remain.
      </p>
    )}
    <main className="app-main" data-region={region}>
      <Surface scenario={scenario} region={region} />
    </main>
    <details className="audit-tools">
      <summary>Local automated accessibility scan</summary>
      <p>With a dialog open, press Alt+Shift+A to scan that dialog.</p>
      <button
        type="button"
        onClick={() => {
          void audit();
        }}
      >
        Run accessibility scan
      </button>
      <pre id="audit-result">Not run</pre>
      <button
        type="button"
        id="measure-frames"
        onClick={() => {
          void measureFrames();
        }}
      >
        Measure local frame pacing
      </button>
      <pre id="performance-result" aria-live="polite">
        Not run
      </pre>
    </details>
  </>,
);
