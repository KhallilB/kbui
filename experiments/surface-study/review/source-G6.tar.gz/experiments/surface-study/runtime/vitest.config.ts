import { defineConfig } from "vitest/config";
export default defineConfig({
  test: {
    environment: "jsdom",
    setupFiles: ["experiments/surface-study/runtime/setup.ts"],
    include: ["experiments/surface-study/**/*.test.tsx"],
  },
});
