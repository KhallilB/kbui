import { type JSX, useEffect, useState } from "react";
export function MotionControl(): JSX.Element {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (reduced) document.documentElement.dataset.studyMotion = "reduce";
    else delete document.documentElement.dataset.studyMotion;
    return () => {
      delete document.documentElement.dataset.studyMotion;
    };
  }, [reduced]);
  return (
    <span data-motion-control>
      <label>
        <input
          type="checkbox"
          checked={reduced}
          onChange={(event) => setReduced(event.target.checked)}
          aria-describedby="motion-preference-help"
        />{" "}
        Reduce motion
      </label>
      <span id="motion-preference-help" className="sr-only">
        Preview override. System reduced motion always remains respected.
      </span>
    </span>
  );
}
