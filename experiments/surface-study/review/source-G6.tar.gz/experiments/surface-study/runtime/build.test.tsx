import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Browser preview delivery", () => {
  it("ships production React without development act diagnostics", () => {
    const entry = readFileSync("experiments/surface-study/runtime/dist/main.js", "utf8");
    expect(entry.includes("not configured to support act")).toBe(false);
  });
  it("versions each surface entry against the delivered script and stylesheet", () => {
    const root = "experiments/surface-study";
    const version = (file: string) =>
      createHash("sha256")
        .update(readFileSync(`${root}/${file}`))
        .digest("hex")
        .slice(0, 12);
    for (const surface of ["commerce", "operations", "culture"]) {
      const html = readFileSync(`${root}/${surface}/index.html`, "utf8");
      expect(html.includes(`main.js?v=${version("runtime/dist/main.js")}`)).toBe(true);
      expect(html.includes(`ui.css?v=${version("runtime/ui.css")}`)).toBe(true);
    }
  });
});
