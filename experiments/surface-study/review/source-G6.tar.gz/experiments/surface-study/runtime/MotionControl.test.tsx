import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CommerceScreen } from "../commerce/Screen";
import { MotionControl } from "./MotionControl";

describe("Motion preference", () => {
  it("respects system mode until user requests reduced preview motion", () => {
    render(<MotionControl />);
    expect(document.documentElement).not.toHaveAttribute("data-study-motion");
    fireEvent.click(screen.getByRole("checkbox", { name: "Reduce motion" }));
    expect(document.documentElement).toHaveAttribute("data-study-motion", "reduce");
    fireEvent.click(screen.getByRole("checkbox", { name: "Reduce motion" }));
    expect(document.documentElement).not.toHaveAttribute("data-study-motion");
  });
  it("clears preview override on unmount", () => {
    const view = render(<MotionControl />);
    fireEvent.click(screen.getByRole("checkbox", { name: "Reduce motion" }));
    view.unmount();
    expect(document.documentElement).not.toHaveAttribute("data-study-motion");
  });
  it("preserves product draft when changing motion preference", () => {
    render(
      <>
        <MotionControl />
        <CommerceScreen />
      </>,
    );
    fireEvent.change(screen.getByLabelText("Quantity"), { target: { value: "3" } });
    fireEvent.click(screen.getByRole("checkbox", { name: "Reduce motion" }));
    expect(screen.getByLabelText("Quantity")).toHaveValue("3");
  });
});
