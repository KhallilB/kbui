import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { FixtureState } from "./FixtureState";

describe("Contextual recoverable surface states", () => {
  it.each(["Commerce", "Operations", "Culture"] as const)(
    "names %s state and offers one explicit recovery",
    (surface) => {
      const recover = vi.fn();
      render(<FixtureState scenario="error" surface={surface} onRecover={recover} />);
      expect(screen.getByRole("alert")).toHaveTextContent(surface);
      expect(screen.getByRole("heading", { name: "We couldn’t load this view" })).toBeVisible();
      fireEvent.click(screen.getByRole("button", { name: "Try again" }));
      expect(recover).toHaveBeenCalledTimes(1);
    },
  );
  it("explains deliberately paused loading without an endless spinner", () => {
    render(<FixtureState scenario="loading" surface="Commerce" onRecover={() => {}} />);
    expect(screen.getByRole("status")).toHaveTextContent("Loading product details");
    expect(screen.getByRole("button", { name: "Show loaded preview" })).toBeEnabled();
  });
});
