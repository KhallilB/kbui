import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";

await mkdir("experiments/surface-study/runtime/dist", { recursive: true });
const result = await Bun.build({
  entrypoints: ["experiments/surface-study/runtime/main.tsx"],
  outdir: "experiments/surface-study/runtime/dist",
  target: "browser",
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  minify: true,
  splitting: true,
  sourcemap: "external",
});
if (!result.success) throw new AggregateError(result.logs, "Study build failed");
console.log(`Built ${result.outputs.length} artifacts`);

const study = "experiments/surface-study";
const coreCSSVersion = createHash("sha256")
  .update(await readFile("packages/css/dist/styles.css"))
  .digest("hex")
  .slice(0, 12);
const versions = new Map<string, string>();
for (const file of ["runtime/dist/main.js", "runtime/ui.css"]) {
  versions.set(
    file,
    createHash("sha256")
      .update(await readFile(`${study}/${file}`))
      .digest("hex")
      .slice(0, 12),
  );
}
for (const surface of ["commerce", "operations", "culture", "transfer"]) {
  const path = `${study}/${surface}/index.html`;
  const html = (await readFile(path, "utf8"))
    .replace(/main\.js(?:\?v=[^" ]+)?/, `main.js?v=${versions.get("runtime/dist/main.js")}`)
    .replace(
      /packages\/css\/dist\/styles\.css(?:\?v=[^" ]+)?/,
      `packages/css/dist/styles.css?v=${coreCSSVersion}`,
    )
    .replace(/ui\.css(?:\?v=[^" ]+)?/, `ui.css?v=${versions.get("runtime/ui.css")}`);
  await writeFile(path, html);
}
