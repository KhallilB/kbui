import { Button } from "@kbui/react";
import type { JSX } from "react";
export type Scenario = "ready" | "loading" | "empty" | "error" | "long" | "action-error";
type Surface = "Commerce" | "Operations" | "Culture";
const subjects = {
  Commerce: "product details",
  Operations: "team tasks",
  Culture: "program sessions",
};
const outcomes = {
  Commerce: "No order has been placed.",
  Operations: "No tasks have been reassigned.",
  Culture: "No booking or payment has been made.",
};
export function FixtureState({
  scenario,
  surface,
  onRecover,
}: {
  scenario: Scenario;
  surface: Surface;
  onRecover: () => void;
}): JSX.Element {
  const loading = scenario === "loading";
  const empty = scenario === "empty";
  const subject = subjects[surface];
  const title = loading
    ? `Loading ${subject}`
    : empty
      ? `No ${subject} to show`
      : "We couldn’t load this view";
  return (
    <section className={`fixture-state state-${scenario}`} aria-label={`${surface} ${scenario}`}>
      <div className="state-marker" aria-hidden="true">
        {loading ? "…" : empty ? "—" : "!"}
      </div>
      <div className="state-copy" role={scenario === "error" ? "alert" : "status"}>
        <span className="eyebrow">
          {surface} / {loading ? "Loading" : empty ? "Empty" : "Connection issue"}
        </span>
        <h2>{title}</h2>
        <p>
          {loading
            ? "This preview pauses loading so you can inspect the layout. Continue when you’re ready."
            : empty
              ? `There are no ${subject} in this sample. Explore populated sample data to try the full experience.`
              : `${outcomes[surface]} Try loading this view again. Your current preview is safe to retry.`}
        </p>
      </div>
      {loading && (
        <div className="state-skeleton" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
      )}
      <Button onClick={onRecover}>
        {loading ? "Show loaded preview" : empty ? "Explore sample data" : "Try again"}
      </Button>
      <small className="state-note">Local study preview · no live service connection</small>
    </section>
  );
}
