# commerce whole-screen blueprint B1

Binding: current study worktree; source d3e0e83 / kbui0.5.0; foundationCG-F1; approved directionC-05.2 / CG-D2; approval review/goal2-approval.json. Current session owns shell/theme/gutters. Same-session region author; independent authorship not demonstrated. Owned paths commerce/Screen.tsx, blueprint/, regions/. Inputs source-snapshot.json, directions/briefs.md and reference.html. Output three modules, tests, region handoffs, isolation previews and preserved original archive.

## Whole-screen reference

reference.html with theme.css and shared/direction-baseline.css fixes composition/type/material. Preview via existing43427server: /experiments/surface-study/commerce/blueprint/reference.html. Inspect390/768/1440. Final app /experiments/surface-study/commerce/; region query ?region=1|2|3; fixture state query ?state=ready|loading|empty|error|long|action-error. Screenshots in blueprint/evidence/. Blueprint illustrative controls have no application behavior.

Layout: Collection navigation above gallery/configurator split. Native finish radios in large cards; public Input quantity, public Button submit, public Dialog summary. Native radios expose missing RadioGroup.

Narrow: Gallery then configuration; quantity/error/submit stay adjacent. Focus stays on invalid quantity; dialog traps, Escape dismisses and returns focus to submit.

## Behavior ownership and seams

Gallery owns selected specimen view, supports object/material/context captions, receives long-title fixture. Configuration owns labeled native finish radios and quantity draft, reports edits/submit. PurchaseSummary receives validated draft/error, displays total and owns review dialog content/close. Shell owns finish/quantity/error/bag state and coordinates submit; no network or persistence. Chalk unavailable; fixture six units, quantity positive integer up to six. These are local fixture facts, not production inventory policy.

Inputs are local typed fixtures. No backend, persistent storage, timers or money movement. Field syntax/selection semantics remain delivery/UI; fixture stock/eligibility and use-case mutation stay in surface shell. Shared kbui core unchanged. Unsupported semantics must stay in gap log, not copied core.

## Three region briefs

1. **Gallery** — first region described in contract above. File regions/Gallery.tsx; one writer. Use only region-owned composition and existing public components. Receives shell callbacks/state, never writes neighbor state. Relevant ready/long and fixture failure boundary states. Keep shell/theme immutable during region work.
2. **Configuration** — second region described above. File regions/Configuration.tsx; same explicit writer, consumes shared theme/reference. Owns focusable form/record controls and emits callbacks. Empty/loading/error/disabled/long states must be available in fixture harness. No layout decisions outside allocated region.
3. **PurchaseSummary** — third region described above. File regions/PurchaseSummary.tsx; callbacks/state supplied by shell. Preserve named adjacent relationships, inline feedback and applicable dialog focus semantics. Include action-error/retry and long-content proof.

Each region gets available width from owning shell grid, min-inline-size0, no body-scroll forcing or fixed content heights. Preview isolation preserves theme/shell allocation; neighboring regions omitted and explicitly labeled isolation. Full reference shared through this file. Region tests may be integrated at owning surface seam where state crosses regions.

## Acceptance and test list

Primary journey, unavailable/disabled choice, invalid quantity/selection, error retaining draft, retry, no/some/all or sold-out as applicable; external state boundaries loading/empty/error have explicit manual fixture recovery. Tests first, then implementation. Browser keyboard/focus, default+long+failure at390/768/1440; public package behavior reused. Root bun run check and shared story gates required for Goal5 handoff. Unknown: native AT, independent authorship and human cohesion until owner review.
