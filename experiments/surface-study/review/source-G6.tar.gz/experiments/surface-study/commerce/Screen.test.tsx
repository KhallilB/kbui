import { fireEvent, render, screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CommerceScreen } from "./Screen";

describe("Commerce fixture journey", () => {
  it("reviews chosen quantity and total in a named dialog", () => {
    render(<CommerceScreen />);
    fireEvent.change(screen.getByLabelText("Quantity"), { target: { value: "2" } });
    fireEvent.click(screen.getByRole("button", { name: "Add to bag · $360" }));
    expect(screen.getByRole("dialog", { name: "Bag review" })).toHaveTextContent(
      "2 × Arc task lamp",
    );
    expect(screen.getByRole("dialog")).toHaveTextContent("$360");
  });
  it("keeps unavailable finish disabled and named", () => {
    render(<CommerceScreen />);
    expect(screen.getByRole("radio", { name: /Chalk/ })).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByText("Unavailable")).toBeVisible();
    expect(screen.getByRole("radio", { name: /Chalk/ })).toHaveAccessibleDescription(
      "Returns in November",
    );
    expect(screen.getByRole("radio", { name: /Fired clay/ })).toBeChecked();
  });
  it.each(["0", "1.5", "7"])("rejects invalid fixture quantity %s", (value) => {
    render(<CommerceScreen />);
    fireEvent.change(screen.getByLabelText("Quantity"), { target: { value } });
    fireEvent.click(screen.getByRole("button", { name: /Add to bag/ }));
    expect(screen.getByText("Choose a whole quantity from 1 to 6.")).toBeVisible();
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });
  it("preserves draft after simulated failure and retries once", () => {
    render(<CommerceScreen scenario="action-error" />);
    fireEvent.change(screen.getByLabelText("Quantity"), { target: { value: "2" } });
    fireEvent.click(screen.getByRole("button", { name: "Add to bag · $360" }));
    expect(screen.getByRole("alert")).toHaveTextContent("Bag update failed");
    expect(screen.getByLabelText("Quantity")).toHaveValue("2");
    fireEvent.click(screen.getByRole("button", { name: "Add to bag · $360" }));
    expect(screen.getByRole("dialog")).toHaveTextContent("$360");
  });
  it.each(["loading", "empty", "error"] as const)("recovers %s fixture explicitly", (scenario) => {
    render(<CommerceScreen scenario={scenario} />);
    expect(screen.queryByLabelText("Quantity")).not.toBeInTheDocument();
    fireEvent.click(
      screen.getByRole("button", {
        name:
          scenario === "loading"
            ? "Show loaded preview"
            : scenario === "empty"
              ? "Explore sample data"
              : "Try again",
      }),
    );
    expect(screen.getByLabelText("Quantity")).toBeVisible();
  });
  it("changes specimen view without changing selection", () => {
    render(<CommerceScreen />);
    fireEvent.click(screen.getByRole("button", { name: "02 / DETAIL" }));
    expect(screen.getByRole("img")).toHaveAccessibleName(/Detail crop/);
    expect(screen.getByRole("img")).toHaveAttribute("src", expect.stringContaining(".webp"));
    expect(screen.getByRole("radio", { name: /Fired clay/ })).toBeChecked();
  });
  it("keeps product controls usable after image failure and offers retry", () => {
    render(<CommerceScreen />);
    fireEvent.error(screen.getByRole("img"));
    expect(screen.getByRole("status")).toHaveTextContent("Photo unavailable");
    expect(screen.getByLabelText("Quantity")).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Retry photo" }));
    expect(screen.getByRole("img")).toBeInTheDocument();
  });
  it("groups bag details, labels the price and exposes an explicit close action", () => {
    render(<CommerceScreen />);
    fireEvent.change(screen.getByLabelText("Quantity"), { target: { value: "2" } });
    fireEvent.click(screen.getByRole("button", { name: "Add to bag · $360" }));
    const dialog = within(screen.getByRole("dialog", { name: "Bag review" }));
    expect(dialog.getByRole("region", { name: "Selected item" })).toHaveTextContent("Fired clay");
    expect(dialog.getByText("Unit price")).toBeVisible();
    expect(dialog.getByText("$180")).toBeVisible();
    expect(dialog.getByText("Bag total")).toBeVisible();
    fireEvent.click(dialog.getByRole("button", { name: "Close bag review" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByLabelText("Quantity")).toHaveValue("2");
  });
});
