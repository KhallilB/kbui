import { Input, RadioGroup } from "@kbui/react";
import type { FormEvent, JSX } from "react";
export function Configuration({
  quantity,
  error,
  onQuantity,
  onSubmit,
  long,
}: {
  quantity: string;
  error: string;
  onQuantity: (v: string) => void;
  onSubmit: (e: FormEvent<HTMLFormElement>) => void;
  long: boolean;
}): JSX.Element {
  return (
    <form id="lamp-config" noValidate onSubmit={onSubmit}>
      <span className="eyebrow">DESIGNED FOR EVERYDAY RITUALS</span>
      <h1 className="product-title">
        {long ? (
          "A warmer working light for a very small studio with a very long name."
        ) : (
          <>
            A warmer
            <br />
            working light.
          </>
        )}
      </h1>
      <div className="productline">
        <span>Arc task lamp</span>
        <strong>$180</strong>
      </div>
      <p className="description">
        A quiet pool of light, exactly where you need it. Adjustable shade. Warm-white LED included.
      </p>
      <RadioGroup
        className="finish-group"
        label="01 / Choose a finish"
        value="clay"
        onValueChange={() => {}}
        name="finish"
      >
        <div className="finishes">
          <RadioGroup.Item className="finish chosen" controlClassName="finish-radio" value="clay">
            <i className="disc clay" aria-hidden="true" />
            <b>Fired clay</b>
            <small>In stock · selected</small>
          </RadioGroup.Item>
          <RadioGroup.Item
            className="finish unavailable"
            controlClassName="finish-radio"
            value="chalk"
            disabled
            aria-describedby="chalk-availability"
          >
            <i className="disc chalk" aria-hidden="true" />
            <b>
              Chalk <span className="availability-tag">Unavailable</span>
            </b>
            <small id="chalk-availability">Returns in November</small>
          </RadioGroup.Item>
        </div>
      </RadioGroup>
      <Input
        label="Quantity"
        inputMode="numeric"
        value={quantity}
        onValueChange={onQuantity}
        description="6 units available in this fixture."
        {...(error ? { error } : {})}
      />
    </form>
  );
}
