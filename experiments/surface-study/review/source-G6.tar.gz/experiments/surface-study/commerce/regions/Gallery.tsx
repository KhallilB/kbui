import { Button } from "@kbui/react";
import { type JSX, useState } from "react";
export function Gallery(): JSX.Element {
  const [view, setView] = useState(0);
  const [failed, setFailed] = useState(false);
  const labels = [
    "Warm glass table lamp, illustrative stock photograph",
    "Detail crop of table lamp shade, illustrative stock photograph",
  ];
  return (
    <section className="gallery" aria-label="Product gallery">
      <div className="gallery-caption">
        <span>COLLECTION 004 / LIGHTING</span>
        <span>0{view + 1} — 02</span>
      </div>
      <figure className={`photo-stage photo-view-${view}`}>
        {failed ? (
          <div className="photo-fallback" role="status">
            <b>Photo unavailable</b>
            <p>Product details remain available.</p>
            <Button onClick={() => setFailed(false)}>Retry photo</Button>
          </div>
        ) : (
          <img
            key={view}
            src="../assets/table-lamp-1280.webp"
            srcSet="../assets/table-lamp-640.webp 640w, ../assets/table-lamp-1280.webp 1280w"
            sizes="(max-width:760px) 90vw, 48vw"
            width="640"
            height="614"
            alt={labels[view]}
            decoding="async"
            onError={() => setFailed(true)}
          />
        )}
        <figcaption>Lighting study / {view === 0 ? "Studio view" : "Shade detail"}</figcaption>
      </figure>
      <fieldset className="thumbnails">
        <legend className="sr-only">Photo views</legend>
        {["01 / STUDIO", "02 / DETAIL"].map((text, i) => (
          <Button
            key={text}
            variant="ghost"
            className={`thumb ${view === i ? "selected" : ""}`}
            aria-pressed={view === i}
            onClick={() => {
              setView(i);
              setFailed(false);
            }}
          >
            {text}
          </Button>
        ))}
      </fieldset>
      <p className="photo-credit">
        Photo by{" "}
        <a href="https://unsplash.com/photos/brown-and-clear-glass-table-lamp-_QcxiSUIwbE">
          sue hughes / Unsplash
        </a>
        . Illustrative lighting reference; fixture finishes and dimensions describe the sample
        product, not this photograph.
      </p>
    </section>
  );
}
