import { type FormEvent, type JSX, useRef, useState } from "react";
import { FixtureState, type Scenario } from "../runtime/FixtureState";
import { Configuration } from "./regions/Configuration";
import { Gallery } from "./regions/Gallery";
import { PurchaseSummary } from "./regions/PurchaseSummary";
export function CommerceScreen({
  scenario = "ready",
  region = "all",
}: {
  scenario?: Scenario;
  region?: string;
} = {}): JSX.Element {
  const [recovered, setRecovered] = useState(false);
  const [quantity, setQuantity] = useState("1");
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [failedOnce, setFailedOnce] = useState(false);
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const total = Number.isFinite(Number(quantity)) ? Math.max(0, Number(quantity) * 180) : 0;
  function submit(e: FormEvent<HTMLFormElement>): void {
    e.preventDefault();
    if (!/^\d+$/.test(quantity) || Number(quantity) < 1 || Number(quantity) > 6) {
      setError("Choose a whole quantity from 1 to 6.");
      document.querySelector<HTMLInputElement>("#lamp-config input[inputmode=numeric]")?.focus();
      return;
    }
    setError("");
    if (scenario === "action-error" && !failedOnce) {
      setFailedOnce(true);
      setActionError("Bag update failed.");
      return;
    }
    setActionError("");
    setOpen(true);
  }
  return (
    <div ref={root} className="concept commerce">
      <nav className="shop-nav" aria-label="Collection">
        <b className="wordmark">edition.</b>
        <span>Lighting / Objects / Our workshop</span>
        <span>Bag preview</span>
      </nav>
      {!recovered && ["loading", "empty", "error"].includes(scenario) ? (
        <FixtureState surface="Commerce" scenario={scenario} onRecover={() => setRecovered(true)} />
      ) : (
        <div className="shop-content">
          {(region === "all" || region === "1") && <Gallery />}
          <div className="configuration">
            {(region === "all" || region === "2" || region === "3") && (
              <Configuration
                quantity={quantity}
                error={error}
                onQuantity={(v) => {
                  setQuantity(v);
                  setError("");
                }}
                onSubmit={submit}
                long={scenario === "long"}
              />
            )}
            {(region === "all" || region === "3") && (
              <PurchaseSummary
                quantity={quantity}
                total={total}
                open={open}
                onOpen={setOpen}
                actionError={actionError}
                container={root.current}
                trigger={trigger}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
