import { Button, Status } from "@kbui/react";
import { type JSX, useEffect, useRef, useState } from "react";
import { FixtureState, type Scenario } from "../runtime/FixtureState";
import { QueueNavigation } from "./regions/QueueNavigation";
import { TaskInspector } from "./regions/TaskInspector";
import { TaskLedger } from "./regions/TaskLedger";
import { fixtureTasks, type Task, type TaskFilter } from "./types";
export function OperationsScreen({
  scenario = "ready",
  region = "all",
}: {
  scenario?: Scenario;
  region?: string;
} = {}): JSX.Element {
  const [recovered, setRecovered] = useState(false);
  const [tasks, setTasks] = useState<Task[]>(() =>
    fixtureTasks.map((task, i) => ({
      ...task,
      title:
        scenario === "long" && i === 0
          ? `${task.title} before the unusually long western-entrance delivery handoff and accessibility inspection`
          : task.title,
    })),
  );
  const [filter, setFilter] = useState<TaskFilter>("review");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(new Set<string>());
  const [inspected, setInspected] = useState("R-104");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [failedOnce, setFailedOnce] = useState(false);
  const result = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (message) result.current?.focus();
  }, [message]);
  const visible = tasks.filter(
    (task) =>
      (filter === "all" || task.status === "review") &&
      `${task.title} ${task.id}`.toLowerCase().includes(query.toLowerCase()),
  );
  const hidden = [...selected].filter((id) => !visible.some((task) => task.id === id)).length;
  const task = tasks.find((item) => item.id === inspected) ?? tasks[0];
  function toggle(id: string): void {
    if (tasks.find((item) => item.id === id)?.locked) return;
    setSelected((before) => {
      const next = new Set(before);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    setMessage("");
  }
  function toggleAll(): void {
    const eligible = visible.filter((item) => !item.locked);
    const remove = eligible.every((item) => selected.has(item.id));
    setSelected((before) => {
      const next = new Set(before);
      for (const item of eligible) {
        if (remove) next.delete(item.id);
        else next.add(item.id);
      }
      return next;
    });
    setMessage("");
  }
  function assign(): void {
    const ids = tasks
      .filter((item) => selected.has(item.id) && !item.locked)
      .map((item) => item.id);
    if (!ids.length) return;
    if (scenario === "action-error" && !failedOnce) {
      setFailedOnce(true);
      setError("Assignment failed.");
      return;
    }
    setTasks((before) =>
      before.map((item) => (ids.includes(item.id) ? { ...item, assignee: "Mira" } : item)),
    );
    setSelected(new Set());
    setError("");
    setMessage(`Assigned ${ids.length} task${ids.length === 1 ? "" : "s"} to Mira.`);
  }
  return (
    <div className="concept operation">
      {(region === "all" || region === "1") && (
        <QueueNavigation filter={filter} onFilter={setFilter} />
      )}
      <div className="workspace-main">
        <div className="workspace-title">
          <div>
            <span className="eyebrow">OPERATIONS / WEST TEAM</span>
            <h1 className="queue-title">
              {filter === "review" ? "Review queue" : "All open tasks"}{" "}
              <small>{String(visible.length).padStart(2, "0")}</small>
            </h1>
          </div>
          <Button
            variant="ghost"
            className="utility"
            onClick={() => {
              setQuery("");
              setFilter("review");
            }}
          >
            Reset filters
          </Button>
        </div>
        {!recovered && ["loading", "empty", "error"].includes(scenario) ? (
          <FixtureState
            surface="Operations"
            scenario={scenario}
            onRecover={() => setRecovered(true)}
          />
        ) : (
          <>
            {message && (
              <Status ref={result} tabIndex={-1} live className="assignment-result">
                {message}
              </Status>
            )}
            <div className="workspace-panes">
              {(region === "all" || region === "2") && (
                <TaskLedger
                  tasks={visible}
                  selected={selected}
                  filter={filter}
                  query={query}
                  hidden={hidden}
                  error={error}
                  onFilter={setFilter}
                  onQuery={setQuery}
                  onToggle={toggle}
                  onAll={toggleAll}
                  onClear={() => {
                    setSelected(new Set());
                    setMessage("");
                    setError("");
                  }}
                  onAssign={assign}
                  onInspect={setInspected}
                />
              )}
              {(region === "all" || region === "3") && task && <TaskInspector task={task} />}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
