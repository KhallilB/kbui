export type Task = {
  id: string;
  title: string;
  location: string;
  due: string;
  status: "review" | "open";
  assignee: string;
  locked: boolean;
};
export type TaskFilter = "review" | "all";
export const fixtureTasks: Task[] = [
  {
    id: "R-104",
    title: "Confirm loading-bay access",
    location: "Dock B",
    due: "10:15",
    status: "review",
    assignee: "Unassigned",
    locked: false,
  },
  {
    id: "R-108",
    title: "Replace scanner battery",
    location: "Intake",
    due: "10:30",
    status: "review",
    assignee: "Unassigned",
    locked: false,
  },
  {
    id: "R-112",
    title: "Verify delivery manifest",
    location: "Dispatch",
    due: "11:00",
    status: "review",
    assignee: "Unassigned",
    locked: false,
  },
  ...Array.from(
    { length: 9 },
    (_, index): Task => ({
      id: `R-${113 + index}`,
      title: index === 7 ? "Audit sealed intake record" : `Inspect station ${index + 1}`,
      location: "West floor",
      due: "12:00",
      status: "open",
      assignee: "Unassigned",
      locked: index === 7,
    }),
  ),
];
