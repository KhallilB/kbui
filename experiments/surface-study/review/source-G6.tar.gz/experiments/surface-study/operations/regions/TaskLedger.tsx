import { Button, Checkbox, Input, Select, Status } from "@kbui/react";
import type { JSX } from "react";
import type { Task, TaskFilter } from "../types";

type Props = {
  tasks: Task[];
  selected: Set<string>;
  filter: TaskFilter;
  query: string;
  hidden: number;
  error: string;
  onFilter: (v: TaskFilter) => void;
  onQuery: (v: string) => void;
  onToggle: (id: string) => void;
  onAll: () => void;
  onClear: () => void;
  onAssign: () => void;
  onInspect: (id: string) => void;
};
export function TaskLedger({
  tasks,
  selected,
  filter,
  query,
  hidden,
  error,
  onFilter,
  onQuery,
  onToggle,
  onAll,
  onClear,
  onAssign,
  onInspect,
}: Props): JSX.Element {
  const eligible = tasks.filter((task) => !task.locked);
  const all = eligible.length > 0 && eligible.every((task) => selected.has(task.id));
  const mixed = !all && eligible.some((task) => selected.has(task.id));
  return (
    <section className="ledger" aria-label="Task ledger">
      <div className="commandbar">
        <Input label="Search tasks" className="search" value={query} onValueChange={onQuery} />
        <Select
          className="native-field filter"
          label="Task status"
          value={filter}
          onValueChange={(next) => {
            if (next === "review" || next === "all") onFilter(next);
          }}
          options={[
            { value: "review", label: "Needs review" },
            { value: "all", label: "All open tasks" },
          ]}
        />
      </div>
      <div className="batch">
        <b>
          {selected.size} selected · {hidden} hidden by filters
        </b>
        <div className="bulk-actions">
          <Button size="sm" disabled={selected.size === 0} onClick={onAssign}>
            Assign selected to Mira
          </Button>
          <Button variant="ghost" size="sm" disabled={selected.size === 0} onClick={onClear}>
            Clear selection
          </Button>
        </div>
      </div>
      {selected.size === 0 && (
        <p className="bulk-hint">Select an unlocked task to enable assignment.</p>
      )}
      {error && (
        <p role="alert" className="inline-error">
          {error} Selection retained; retry assignment.
        </p>
      )}
      {tasks.length === 0 ? (
        <div className="empty-records">
          <p>No matching tasks.</p>
          <Button onClick={() => onQuery("")}>Clear search</Button>
        </div>
      ) : (
        <table className="task-table">
          <caption>Fixture tasks · select many, inspect one</caption>
          <thead>
            <tr>
              <th>
                <Checkbox
                  label="Select all visible eligible tasks"
                  visuallyHidden
                  checked={all}
                  indeterminate={mixed}
                  onCheckedChange={onAll}
                  disabled={eligible.length === 0}
                />
              </th>
              <th>Task / reference</th>
              <th>Due</th>
              <th>State</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task) => (
              <tr key={task.id}>
                <td>
                  <Checkbox
                    label={`Select ${task.id}`}
                    visuallyHidden
                    checked={selected.has(task.id)}
                    disabled={task.locked}
                    onCheckedChange={() => onToggle(task.id)}
                  />
                </td>
                <td>
                  <Button
                    variant="ghost"
                    className="task-title"
                    aria-label={`Inspect ${task.id}`}
                    onClick={() => onInspect(task.id)}
                  >
                    {task.title}
                  </Button>
                  <small>
                    {task.id} / {task.location} / {task.assignee}
                    {task.locked ? " / Locked" : ""}
                  </small>
                </td>
                <td>{task.due}</td>
                <td>
                  <Status className="state" tone={task.status === "review" ? "warning" : "neutral"}>
                    {task.status === "review" ? "Review" : "Open"}
                  </Status>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <div className="ledger-footer">
        <span>Showing {tasks.length} of 12 open tasks</span>
        <span>Fixture timestamp 08:42</span>
      </div>
    </section>
  );
}
