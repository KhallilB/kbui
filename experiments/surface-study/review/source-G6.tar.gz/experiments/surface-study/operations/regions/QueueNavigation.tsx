import { Button } from "@kbui/react";
import type { JSX } from "react";
import type { TaskFilter } from "../types";
export function QueueNavigation({
  filter,
  onFilter,
}: {
  filter: TaskFilter;
  onFilter: (v: TaskFilter) => void;
}): JSX.Element {
  return (
    <aside className="workspace-rail" aria-label="Queue navigation">
      <b className="relaymark">
        R<span>RELAY</span>
      </b>
      <Button
        className={`railitem ${filter === "review" ? "active" : ""}`}
        variant="ghost"
        onClick={() => onFilter("review")}
        aria-pressed={filter === "review"}
      >
        01 Review queue <b>3</b>
      </Button>
      <Button
        className={`railitem ${filter === "all" ? "active" : ""}`}
        variant="ghost"
        onClick={() => onFilter("all")}
        aria-pressed={filter === "all"}
      >
        02 All tasks <b>12</b>
      </Button>
      <div className="shift">
        WEST TEAM
        <br />
        SHIFT 08:00–16:00
        <br />
        <span>Local fixtures · no live sync</span>
      </div>
    </aside>
  );
}
