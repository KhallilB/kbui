import { Callout } from "@kbui/react";
import type { JSX } from "react";
import type { Task } from "../types";
export function TaskInspector({ task }: { task: Task }): JSX.Element {
  return (
    <aside className="inspector" aria-label="Task inspector">
      <div className="inspector-header">
        <span className="eyebrow">{task.id} / TASK DETAIL</span>
      </div>
      <h2 key={task.id}>{task.title}</h2>
      <dl>
        <div>
          <dt>Assignee</dt>
          <dd>{task.assignee}</dd>
        </div>
        <div>
          <dt>Location</dt>
          <dd>{task.location}</dd>
        </div>
        <div>
          <dt>Due today</dt>
          <dd>{task.due}</dd>
        </div>
      </dl>
      <Callout className="task-note" title={task.locked ? "Record locked" : "Review note"}>
        {task.locked
          ? "This fixture record cannot be assigned."
          : "Confirm details with site lead before dispatch."}
      </Callout>
      <details>
        <summary>Activity (4) · fixture notes</summary>
        <ol>
          <li>08:42 Mira requested review.</li>
          <li>08:30 Location checked.</li>
          <li>08:12 Task received.</li>
          <li>08:00 Shift opened.</li>
        </ol>
      </details>
    </aside>
  );
}
