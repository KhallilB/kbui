/** Bounded opaque-text witness for known study modal notes; not general conformance. */
export function visualTextProof(element: HTMLElement) {
  const style = getComputedStyle(element);
  const rgb = (value: string) => value.match(/[\d.]+/g)?.map(Number) ?? [];
  const fg = rgb(style.color);
  let current: HTMLElement | null = element;
  let background: number[] = [];
  const constraints: string[] = [];
  let backgroundCSS: string | null = null;
  if (!/^rgba?\(/.test(style.color) || (fg.length === 4 && fg[3] !== 1))
    constraints.push("non-opaque or unsupported foreground");
  if (element.childElementCount) constraints.push("nested text styles require separate proof");
  if (style.textShadow !== "none") constraints.push("text shadow requires separate proof");
  while (current) {
    const paint = getComputedStyle(current);
    if (Number(paint.opacity) !== 1 || paint.filter !== "none" || paint.mixBlendMode !== "normal")
      constraints.push("non-opaque paint context");
    if (paint.backgroundImage !== "none")
      constraints.push("background image requires manual proof");
    const color = rgb(paint.backgroundColor);
    if (color.length === 4 && (color[3] ?? 0) > 0 && color[3] !== 1)
      constraints.push("translucent background requires compositing proof");
    if (!background.length && (color.length === 3 || color[3] === 1)) {
      background = color;
      backgroundCSS = paint.backgroundColor;
    }
    current = current.parentElement;
  }
  const luminance = (color: number[]) =>
    color
      .slice(0, 3)
      .map((v) => v / 255)
      .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
      .reduce((sum, value, i) => sum + value * ([0.2126, 0.7152, 0.0722][i] ?? 0), 0);
  const ratio =
    background.length && fg.length >= 3
      ? (Math.max(luminance(fg), luminance(background)) + 0.05) /
        (Math.min(luminance(fg), luminance(background)) + 0.05)
      : 0;
  const required =
    Number.parseFloat(style.fontSize) >= 24 ||
    (Number.parseFloat(style.fontSize) >= 18.667 && Number(style.fontWeight) >= 700)
      ? 3
      : 4.5;
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  let glyphs = 0;
  let obscured = 0;
  let outside = 0;
  while (node) {
    const text = node.textContent ?? "";
    for (let i = 0; i < text.length; i++) {
      if (!text[i]?.trim()) continue;
      const range = document.createRange();
      range.setStart(node, i);
      range.setEnd(node, i + 1);
      for (const rect of range.getClientRects()) {
        if (!rect.width || !rect.height) continue;
        glyphs++;
        const x = rect.x + rect.width / 2,
          y = rect.y + rect.height / 2;
        if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) {
          outside++;
          continue;
        }
        const top = document.elementsFromPoint(x, y)[0];
        if (
          !top ||
          !node.parentElement ||
          (top !== node.parentElement && !top.contains(node.parentElement))
        )
          obscured++;
      }
    }
    node = walker.nextNode();
  }
  return {
    text: element.textContent,
    foreground: style.color,
    background: backgroundCSS,
    ratio,
    required,
    glyphs,
    obscured,
    outside,
    constraints,
    pass: ratio >= required && glyphs > 0 && !obscured && !outside && !constraints.length,
  };
}
