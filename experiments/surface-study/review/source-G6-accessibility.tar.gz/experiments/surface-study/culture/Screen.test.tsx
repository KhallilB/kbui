import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { CultureScreen } from "./Screen";

describe("Culture fixture journey", () => {
  it("reviews two standard tickets in a named dialog", async () => {
    render(<CultureScreen />);
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("dialog", { name: "Reservation review" })).toHaveTextContent(
      "2 standard tickets · $48",
    );
  });
  it("requires fixture student ID acknowledgement and keeps draft", async () => {
    render(<CultureScreen />);
    await userEvent.click(screen.getByRole("combobox", { name: "Ticket class" }));
    await userEvent.click(await screen.findByRole("option", { name: "Student · $16 with ID" }));
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("alert")).toHaveTextContent("Confirm student ID");
    fireEvent.click(screen.getByLabelText("I will bring student ID"));
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("dialog")).toHaveTextContent("2 student tickets · $32");
  });
  it.each(["0", "1.5", "7"])("rejects invalid ticket quantity %s", (value) => {
    render(<CultureScreen />);
    fireEvent.change(screen.getByLabelText("Ticket quantity"), { target: { value } });
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("alert")).toHaveTextContent("Choose a whole quantity from 1 to 6.");
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByLabelText("Ticket quantity")).toHaveFocus();
  });
  it("switches dates to sold-out event without booking action", async () => {
    render(<CultureScreen />);
    fireEvent.click(screen.getByRole("radio", { name: /07 Saturday/ }));
    expect(screen.getByRole("heading", { name: "Sound lab" })).toBeVisible();
    expect(screen.getByText("Sold out · choose another evening.")).toBeVisible();
    expect(screen.queryByRole("button", { name: "Review reservation" })).not.toBeInTheDocument();
  });
  it("chooses a free event and uses zero total", async () => {
    render(<CultureScreen />);
    fireEvent.click(
      screen.getByRole("button", { name: "Explore ticket options for A room for slow sound" }),
    );
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("dialog")).toHaveTextContent("2 standard tickets · $0");
  });
  it("retains ticket draft on failure, retries and clears stale selection on date change", async () => {
    render(<CultureScreen scenario="action-error" />);
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("alert")).toHaveTextContent("Reservation preview failed");
    expect(screen.getByLabelText("Ticket quantity")).toHaveValue("2");
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(screen.getByRole("dialog")).toHaveTextContent("$48");
    fireEvent.click(
      within(screen.getByRole("dialog")).getByRole("button", { name: "Back to program" }),
    );
    fireEvent.click(screen.getByRole("radio", { name: /08 Sunday/ }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Repair and reimagine" })).toBeVisible();
  });
  it.each(["loading", "empty", "error"] as const)("recovers %s fixture", (scenario) => {
    render(<CultureScreen scenario={scenario} />);
    fireEvent.click(
      screen.getByRole("button", {
        name:
          scenario === "loading"
            ? "Show loaded preview"
            : scenario === "empty"
              ? "Explore sample data"
              : "Try again",
      }),
    );
    expect(screen.getByRole("heading", { name: "Print after dark" })).toBeVisible();
  });
  it("reviews session date, time and venue with a clear close action", async () => {
    render(<CultureScreen />);
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    const dialog = within(screen.getByRole("dialog", { name: "Reservation review" }));
    expect(dialog.getByRole("region", { name: "Session details" })).toHaveTextContent("Studio 2");
    expect(dialog.getByText("06 November 2026")).toBeVisible();
    expect(dialog.getByText("19:00–20:30")).toBeVisible();
    fireEvent.click(dialog.getByRole("button", { name: "Close reservation review" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByLabelText("Ticket quantity")).toHaveValue("2");
  });
  it("keeps long session names consistent between program and review", async () => {
    render(<CultureScreen scenario="long" />);
    const name = screen.getByRole("heading", { name: /Print after dark/ }).textContent;
    fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
    expect(within(screen.getByRole("dialog")).getByRole("heading", { level: 3 })).toHaveTextContent(
      name ?? "missing",
    );
  });
});

it("associates student validation with acknowledgement and clears corrected error", async () => {
  render(<CultureScreen />);
  await userEvent.click(screen.getByRole("combobox", { name: "Ticket class" }));
  await userEvent.click(await screen.findByRole("option", { name: "Student · $16 with ID" }));
  fireEvent.click(screen.getByRole("button", { name: "Review reservation" }));
  const student = screen.getByRole("checkbox", { name: "I will bring student ID" });
  expect(student).toHaveAccessibleDescription(
    "Confirm student ID before reviewing student tickets.",
  );
  expect(student).toHaveAttribute("aria-invalid", "true");
  expect(student).toHaveFocus();
  expect(screen.getByLabelText("Ticket quantity")).not.toHaveAccessibleDescription(
    expect.stringContaining("Confirm student ID"),
  );
  await userEvent.click(student);
  expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  expect(student).not.toHaveAttribute("aria-invalid", "true");
});
