import { Button, Status } from "@kbui/react";
import type { JSX, ReactNode } from "react";
import type { EventFixture } from "../types";
export function EventProgram({
  events,
  selected,
  onSelect,
  reservation,
}: {
  events: EventFixture[];
  selected: string;
  onSelect: (id: string) => void;
  reservation: ReactNode;
}): JSX.Element {
  return (
    <section className="schedule" aria-label="Evening program">
      {events.map((event, index) => (
        <article className={`event ${index > 0 ? "second-event" : ""}`} key={event.id}>
          <div className="event-time">
            {event.time}
            <span>—{event.end}</span>
          </div>
          <div className="event-copy">
            <span className="eyebrow">
              {event.kind.toUpperCase()} / {event.room.toUpperCase()}
            </span>
            <h2>{event.title}</h2>
            <p>{event.description}</p>
            <div className="event-facts">
              <span>Step-free entrance</span>
              <span>Materials included</span>
              <span>{event.price === 0 ? "Free" : "From $16"}</span>
            </div>
            {event.capacity === 0 ? (
              <Status className="sold-out">Sold out · choose another evening.</Status>
            ) : (
              <>
                <Button
                  className="event-choose"
                  variant="ghost"
                  aria-label={`${event.id === selected ? "Selected session" : "Explore ticket options"} for ${event.title}`}
                  aria-pressed={event.id === selected}
                  onClick={() => onSelect(event.id)}
                >
                  {event.id === selected ? "Selected session" : "Explore ticket options"} ↗
                </Button>
                {event.id === selected && reservation}
              </>
            )}
          </div>
        </article>
      ))}
    </section>
  );
}
