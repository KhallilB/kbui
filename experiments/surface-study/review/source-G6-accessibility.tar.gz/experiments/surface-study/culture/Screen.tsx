import { type FormEvent, type JSX, useRef, useState } from "react";
import { FixtureState, type Scenario } from "../runtime/FixtureState";
import { EventProgram } from "./regions/EventProgram";
import { ProgramNavigation } from "./regions/ProgramNavigation";
import { TicketReservation } from "./regions/TicketReservation";
import { events as fixtureEvents } from "./types";
export function CultureScreen({
  scenario = "ready",
  region = "all",
}: {
  scenario?: Scenario;
  region?: string;
} = {}): JSX.Element {
  const events =
    scenario === "long"
      ? fixtureEvents.map((item) => ({
          ...item,
          title: `${item.title} — a very long evening of shared practice, sound, print and welcoming first-time visitors`,
        }))
      : fixtureEvents;
  const [recovered, setRecovered] = useState(false);
  const [day, setDay] = useState("06");
  const [selected, setSelected] = useState("print");
  const [quantity, setQuantity] = useState("2");
  const [ticketClass, setTicketClass] = useState("standard");
  const [studentId, setStudentId] = useState(false);
  const [error, setError] = useState("");
  const [open, setOpen] = useState(false);
  const [failedOnce, setFailedOnce] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const event = events.find((item) => item.id === selected) ?? events[0];
  const price = ticketClass === "student" && event && event.price > 0 ? 16 : (event?.price ?? 0);
  const total = Number.isFinite(Number(quantity)) ? Math.max(0, Number(quantity) * price) : 0;
  function choose(id: string): void {
    setSelected(id);
    setTicketClass("standard");
    setStudentId(false);
    setError("");
    setOpen(false);
  }
  function changeDay(next: string): void {
    setDay(next);
    choose(events.find((item) => item.day === next)?.id ?? "");
  }
  function reserve(e: FormEvent<HTMLFormElement>): void {
    e.preventDefault();
    if (!event || !event.capacity) return;
    if (!/^\d+$/.test(quantity) || Number(quantity) < 1 || Number(quantity) > event.capacity) {
      setError(`Choose a whole quantity from 1 to ${event.capacity}.`);
      e.currentTarget.querySelector<HTMLInputElement>("input[inputmode=numeric]")?.focus();
      return;
    }
    if (ticketClass === "student" && !studentId) {
      setError("Confirm student ID before reviewing student tickets.");
      e.currentTarget.querySelector<HTMLInputElement>("input[type=checkbox]")?.focus();
      return;
    }
    if (scenario === "action-error" && !failedOnce) {
      setFailedOnce(true);
      setError("Reservation preview failed. Your draft is retained; retry.");
      return;
    }
    setError("");
    setOpen(true);
  }
  const reservation =
    event && event.capacity > 0 && (region === "all" || region === "3") ? (
      <TicketReservation
        event={event}
        quantity={quantity}
        ticketClass={ticketClass}
        studentId={studentId}
        error={error}
        total={total}
        open={open}
        onOpen={setOpen}
        onQuantity={(v) => {
          setQuantity(v);
          setError("");
        }}
        onClass={(v) => {
          setTicketClass(v);
          setStudentId(false);
          setError("");
        }}
        onStudent={(value) => {
          setStudentId(value);
          setError("");
        }}
        onSubmit={reserve}
        container={root.current}
        trigger={trigger}
      />
    ) : null;
  return (
    <div className="concept culture" ref={root}>
      <div className="publication">
        <div className="issue">
          <span>OAKLAND / 06—08 NOVEMBER</span>
          <span>ISSUE NO. 07 / AUTUMN 2026</span>
        </div>
        <div className="masthead">
          <h1 className="program-title">
            Night
            <br />
            <em>School</em>
          </h1>
          <div className="editorial">
            <span className="eyebrow">STAY OUT. LEARN SOMETHING.</span>
            <p>
              Three evenings.
              <br />A few good questions.
              <br />A room full of new people.
            </p>
            <span className="edition-note">
              Sound, print & experiments
              <br />
              Doors open at 18:30 · Fictional program
            </span>
          </div>
          <div className="printmark" aria-hidden="true">
            N<br />
            °7
          </div>
        </div>
        {!recovered && ["loading", "empty", "error"].includes(scenario) ? (
          <FixtureState
            surface="Culture"
            scenario={scenario}
            onRecover={() => setRecovered(true)}
          />
        ) : (
          <div className="program">
            {(region === "all" || region === "1") && (
              <ProgramNavigation day={day} onDay={changeDay} />
            )}
            {(region === "all" || region === "2") && (
              <EventProgram
                events={events.filter((item) => item.day === day)}
                selected={selected}
                onSelect={choose}
                reservation={reservation}
              />
            )}
            {region === "3" && (
              <section className="schedule" aria-label="Ticket isolation">
                {reservation}
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
