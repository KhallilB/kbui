import { Button, Dialog } from "@kbui/react";
import type { JSX, RefObject } from "react";
export function PurchaseSummary({
  quantity,
  total,
  open,
  onOpen,
  actionError,
  container,
  trigger,
}: {
  quantity: string;
  total: number;
  open: boolean;
  onOpen: (open: boolean) => void;
  actionError: string;
  container: HTMLDivElement | null;
  trigger: RefObject<HTMLButtonElement | null>;
}): JSX.Element {
  return (
    <section aria-label="Purchase summary">
      <div className="buyline">
        <Button ref={trigger} className="purchase" type="submit" form="lamp-config">
          Add to bag · ${total}
        </Button>
      </div>
      {actionError && <p role="alert">{actionError} Your quantity is retained; try again.</p>}
      <p className="shipping">Ships in 3 working days · No live purchase</p>
      <div className="specrow">
        <span>
          Ø 28 cm
          <br />
          <small>Shade diameter</small>
        </span>
        <span>
          2700 K<br />
          <small>Warm-white light</small>
        </span>
      </div>
      <Dialog
        open={open}
        onOpenChange={onOpen}
        onOpenChangeComplete={(isOpen) => {
          if (!isOpen) trigger.current?.focus();
        }}
      >
        <Dialog.Content container={container} className="study-dialog bag-dialog">
          <Dialog.Header className="overlay-header">
            <span className="eyebrow">EDITION / YOUR SELECTION</span>
            <Dialog.Title className="overlay-title">Bag review</Dialog.Title>
            <Dialog.Description className="overlay-description">
              Local fixture only. No order placed.
            </Dialog.Description>
            <Dialog.Close
              render={<Button variant="ghost" />}
              className="overlay-close"
              aria-label="Close bag review"
            >
              <svg aria-hidden="true" width="18" height="18" viewBox="0 0 20 20" fill="none">
                <path
                  d="m5 5 10 10M15 5 5 15"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
            </Dialog.Close>
          </Dialog.Header>
          <Dialog.Body className="overlay-body" role="region" aria-label="Selected item">
            <div className="overlay-item-heading">
              <span className="overlay-index" aria-hidden="true">
                01
              </span>
              <div>
                <h3>{quantity} × Arc task lamp</h3>
                <p>Fired clay · Lighting collection 004</p>
              </div>
            </div>
            <dl className="overlay-facts">
              <div>
                <dt>Quantity</dt>
                <dd>{quantity}</dd>
              </div>
              <div>
                <dt>Unit price</dt>
                <dd>$180</dd>
              </div>
              <div>
                <dt>Dispatch</dt>
                <dd>3 working days</dd>
              </div>
            </dl>
          </Dialog.Body>
          <div className="overlay-total">
            <span>Bag total</span>
            <strong>${total}</strong>
          </div>
          <Dialog.Footer className="overlay-footer">
            <p className="overlay-note">
              Review preview only. Continue browsing to adjust your selection.
            </p>
            <Dialog.Actions className="overlay-actions">
              <Dialog.Close render={<Button />}>Continue browsing</Dialog.Close>
            </Dialog.Actions>
          </Dialog.Footer>
        </Dialog.Content>
      </Dialog>
    </section>
  );
}
