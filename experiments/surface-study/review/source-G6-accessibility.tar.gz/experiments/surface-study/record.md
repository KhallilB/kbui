# Catalog-growth study · execution record

> **G6-A follow-up supersedes readiness below:** accessibility defects fixed and independently re-reviewed; 232 normal/reduced browser tests, 10 targeted forced-color checks and 48 study tests pass. VoiceOver sign-off remains pending by owner instruction. Formal exact-head gate remains blocked without a committed review round. Bezl trial held. See [follow-up and current obligations](review/accessibility-followup.md). Original G6 evidence below is historical.


Current checkpoint: **Goal6 / shared delivery implemented and locally verified; unreleased/uncommitted. Full independent-composition result partial. Results/adoption handoff prepared.**

Single tracker for this run. Historical runs remain in their original worktrees; their approvals do not apply to current CG-D2.

## Bindings

- Repository/worktree: `/Users/khallil/proj/kbui/.claude/worktrees/study-catalog-growth`.
- Scratch branch: `worktree/study-catalog-growth`; source: `d3e0e832951088ea1ddd14bba3f198ecb0f680b9`, kbui 0.5.0.
- Named source archive and file manifest: `source-snapshot.json`; clean tracked source, no imported preparation.
- Surfaces: Commerce C-05 Material Room, Operations O-05 Dispatch Ledger, Culture K-05 Printed Program.
- Current owner: current session; paths `experiments/surface-study/**`. No independent-author route authorized.
- Inputs: updated surface-design-study (six goal checksums pass); current catalog and contracts; prior closeouts in design-product-component-worlds and study-kbui-full-run.
- Expected outputs: foundation/coverage, three briefs, nine visual studies, comparison board, then after approvals blueprints, regions, integration and justified shared component delivery/transfer.

## Stages

| Goal | State | Evidence / next action |
|---|---|---|
| 1 | Complete documentary foundation | CG-F1, current0.5.0source/163member snapshot. |
| 2 | Approved CG-D2 | Direct owner statement and exact reviewed bytes in review/goal2-approval.json; original packet archived. |
| 3 | Implemented/checked for all3surfaces | ThreeB1handoffs/themes/references;9rendered width references. |
| 4 | NineR1modules implemented/checked; independent authorship unproven | Three modules/handoffs per surface, originals preserved;31focused tests after assertionRed;9isolated primary actions;27isolation width cases. |
| 5 | Approved I4 | Owner approval in review/goal5-approval.json; I1–I4 preserved. |
| 6 | Implemented / locally checked / unreleased | 18 public components, 210 stories, 47 study tests, 54 scenes, fresh transfer; results.md and adoption.md. Independent/AT/host limits remain. |


## Decisions and evidence limits

Current main differs from stale root checkout and dated product/roadmap prose: exports15 components, package versions0.5.0. Infigraph search returns old Facet-era symbols; direct source used after mismatched index evidence. No index refresh or source edit required for static direction stage.

Prior runs delivered theme/composition work without new core components. Updated run keeps three original surface families but chooses configuration, bulk selection and date/ticket exploration to test missing reusable interactions. G1 Select, G2 Checkbox and G3 Tabs are hypotheses, not promised counts. Native control baseline may disprove a candidate. Table/Split/EmptyState remain consumer/native compositions until reproducible need justifies more.

Checks for Goals1/2 are documentary, static rendering and board navigation. No production behavior changed: TDD Red/Green N/A; static art-direction exception uses source integrity, real browser rendering and links/disclosures/focus checks. Root package checks are deferred until maintained packages change. No universal fit, accessibility conformance, human preference, independent-builder, released-package or M2/M3-completion claim.

## Goal 2 checkpoint

Awaiting direct owner review: approve three proposed B directions and task/state challenges, request changes, or reject. Recommendation: approve C-B/O-B/K-B with noted space/density/display tradeoffs. Approval unlocks Goal3 Commerce blueprint then full Goals3–5 for all three surfaces. Shared component scope returns at Goal5 before implementation. Reviewed revisions/pins and preview paths live in review/goal2.json. No approval inferred from silence or technical checks.

Preview command from worktree root: `python3 -m http.server 43427 --bind 127.0.0.1`. Board: http://127.0.0.1:43427/experiments/surface-study/directions/.

## Checks actually run · CG-D1

- `shasum -a 256 -c references/goals.sha256` in skill directory: all six preserved goals pass.
- `python3 experiments/surface-study/evidence/verify.py` from worktree root: named archive and163tracked members match; unique IDs;7links resolve to files/anchors; whitespace clean including untracked deliverables;11authored text/background pairs >=4.5:1 (lowest5.03:1). Selected-pair calculation is not a full accessibility audit.
- Actual IAB browser renders at390/768/1440: no body or concept horizontal overflow;3concepts and9small studies present. Wide comparison side by side; narrow/tablet stack. Screenshots and actual geometry in evidence/board-*.png and renders.json.
- Tablet visual inspection found awkward word splitting in three narrow columns; revised board to stack below1050px, repeated all three widths. This is direction-board composition only.
- Keyboard: Tab reaches visible outlined summary; Enter opens/closes all3native disclosures; Enter activates Culture challenge anchor. evidence/keyboard.json. Browser kept open as deliverable.
- `git diff --check`: exit0; no tracked package/source changes. Root package build/test/story suites not run: static artifact stage changes no maintained component behavior. No Red/Green claimed.
- Initial localhost board visit happened before preview server started; recovered by opening running board. Shell HTTP probe blocked by sandbox; actual browser navigation and CSS render succeeded. Neither setup failure counts as TDD Red.

Snapshot and review screenshots establish input/artifact identity; user preference remains pending. No blueprint, region or shared component implementation started. Pending owner choices: approve CG-D1 direction/task scope, request changes, or reject. After approval resume Commerce Goal3, then remaining surfaces automatically until Goal5 pause.


## Owner change request · CG-D2

Owner requested designs be holistically different, including components/layouts. CG-D1 was not approved. Preserved original packet in review/preserved/CG-D1.tar.gz; continue same worktree/record/source. Root cause in direction evidence: three equal vertical specimens reused headline/content/selector/action ordering, despite different palette/type. Revised actual direction studies into unequal gallery/configuration, rail/table/inspector workspace and masthead/date-spine/program. Distinct control anatomy: finish tiles and capsule quantity, mixed square checks and compact commands, vertical date typography and square inline ticket band. Added neutral structure diagrams and seven-axis component/layout matrix. These are still Goal2 art-direction studies, not Goal3 region/implementation contracts.

CG-D2 direction revisions C-05.2/O-05.2/K-05.2; coverage CG-C2. Commerce finish uses visible radio choices (G4 hypothesis); Select G1 reuse now Operations/Culture. No core component scope approved. Updated briefs carry explicit prohibition on convergence to common hero/card/form pattern and require palette/logo-independent inspection plus distinct narrow rearrangements.

Test-first exception remains static visual design: no maintained production behavior changed; only native links/disclosures operate. Root packages/source remain unchanged. Current checks and exact reviewed bytes are pinned in review/goal2.json after browser replay. Pending: owner review CG-D2, then Goal3 only after approval. Second pause remains after Goal5.


## Checks actually run · CG-D2

- Replayed actual browser CSS viewport widths390/768/1440; measured innerWidth before recording. Browser display scaling initially yielded355/698/1309; viewport dimensions adjusted to reach exact requested CSS widths without changing browser preferences. Final renders.json records actual dimensions.
- All3concepts: no body or component horizontal overflow at all3widths. Layout measurements show Commerce split/stack, Operations rail/table/inspector versus narrow record flow, Culture vertical/horizontal date spine. Nine alternative specimens and3neutral structural diagrams retained.
- Visually inspected revised Commerce wide, Operations wide, Culture wide and Culture narrow. Preserved full boards at3widths plus viewport previews. Static controls are labeled previews, not task-completion proof.
- Keyboard Enter opened/closed all4native review disclosures with solid visible outline; all3inspection anchors reached correct study URLs. evidence/keyboard.json.
- `python3 experiments/surface-study/evidence/verify.py`: exit0,163source members/archive unchanged,7local link/anchor targets resolve, unique IDs, clean whitespace,11retained text/background pairs pass selected-pair contrast check. `git diff --check`: exit0. Package build/test/story gates not rerun for static direction revision.
- Agent visual judgment: representative layouts/component mix now differ holistically; neutral diagrams expose differences independent of palette. Human confirmation still pending. No application behavior, independent authorship, component-growth or accessibility-conformance claim.

Current checkpoint: CG-D2 awaiting owner review (approve / request changes / reject). Recommendation: approve revised holistic direction/task/component challenges; new shared component scope remains conditional on reproduced need atGoal5. Goals3–6 held. Next action after direct approval: Commerce blueprint, remaining surfaces throughGoal5, then second owner pause.


## Goal2 approved / execution resumed

Owner explicitly approvedCG-D2 and requested Goals3–5 with pause afterGoal5. All reviewed hashes matched before approval. Exact statement and reviewed artifact hashes in review/goal2-approval.json. Goal2 waiting cleared; current next action Commerce blueprint then regions/integration. No workers authorized; nine regions will be separately modular but same-session authored, independent composition remains unproven. Applying staff-engineer-frontend for typed React state and accessible integration.

Slice order: Commerce working vertical outcome, Operations working vertical outcome, Culture working vertical outcome, cross-surface integration/review. Each surface owns its blueprint/theme/shell and three regions; shared runtime diagnostics/build are coordinator-owned. Public kbui packages stay frozen throughGoal5; native controls expose catalog gaps. Consumer fixture policy remains explicit and local. No payments, backend, persistence or production policy claims.

Commerce Goal3 B1 / Goal4 R1 complete; first integrated vertical preview running.10component tests first failed on missing Quantity against explicit placeholder, then same assertions all pass. Initial test harness tsconfig-path failure fixed before recording assertionRed. Actual browser quantity2 opens Bag review total$360 and Escape dismisses. Original3region modules/handoffs preserved before later integration. Whole-screen/isolation/state browser matrix follows in cross-surface verification. Native radios remain visible G4 baseline; no core changes.


## Goals3–5 / integration I1 review checkpoint

Scope executed: Commerce first through reference/three modules/integration, then Operations and Culture. All used approvedCG-D2/source d3e0e83. State/fixture policy and layer ownership documented in each blueprint. Public kbui0.5.0imports; no core source or package contracts changed. Independent authorship/reviewer remains unproven: same session wrote separate modules, shell and review. Stage execution does not establish independent-composition fitness.

### Actual evidence

- `bun install --frozen-lockfile --ignore-scripts`:529locked packages installed; baseline build pass. Study-local ignored dependency links use installed versions.
- Component assertionRed: Commerce10tests missingQuantity, Operations10missingSelectR104, Culture11missingReviewreservation against explicit placeholders. Initial harness tsconfig path error was fixed before assertionRed and does not count. Same31assertions pass after implementation; current combined log review/evidence-goal5/regions-green.log.
- `bun experiments/surface-study/runtime/build.ts`: browser build passes. `bunx --no-install tsc --noEmit -p experiments/surface-study/runtime/tsconfig.json`: pass. Root `bun run check`: pass, including build/lint/type/tests/pack. Existing CSS specificity warnings are warnings, not hidden as a clean warning-free audit.
- `bun run test:stories`:166tests/32files pass. First sandbox listenerEPERM fixed by approved tool escalation; environmental failure never counted asRed.
- Browser:54configured scene scans (6scenes ×3surfaces ×3actual390/768/1440widths) plus9post-action-failure scans. Final0recordedWCAG2A/AA/2.1AAviolations and no body/concept overflow;Commercegradientcaption contrast is incomplete, not passed.18Culturecases replayed after contrast/harness correction. Actual viewport CSS innerWidth measured; display scaling adjusted without changing browser preferences.
- Nine primary keyboard journeys across3surfaces/3widths: Commerce2units/$360; Operations hidden-scope assignment; Culture date arrows/soldout/studentID/$32. All include one-shot failure/retry; dialogsEscape return focus to purchase/ticket trigger. Additional nine isolated-region actions pass.31component tests cover invalid quantities, disabled/locked, zero-price event, mixed state, empty search/recovery and draft preservation.
- Nine blueprint renders and27isolated width renders saved. Isolation before repair put Operationscontent190px/Culture125px in first tracks; explicit coordinator-owned track assignment restored intended allocation,27replays no overflow. Source R1archives preserved; this was an integration harness defect.
- Real consumer reduced-motion preference/AT/native browser zoom not exercised: CUA exposes viewport/visibility only. Consumer CSSOM finds8reduced-motion media rules; actual preference false; normal public Button120ms in each identity. Shared166storytests include actual reduced-motion. Do not relabel source inspection as consumer preference emulation.

### Integration decisions and preserved deviations

No common screen template imposed: object/gallery/configuration, rail/ledger/inspector and publication/date-spine/program remain distinct. Native radio/select/checkbox/disclosure recipes expose missing catalog contracts rather than copying kbui. Operations activity uses disclosure, Culture date controls use radio filters rather than nonexistent shared Tabs. Search remains within ledger instead of spanning inspector. Public Input quantity is a field rather than decorative mocked stepper. These are explicit deviations/limitations, not silently claimed exact reference matches.

Coordinator integration changes: public root className hooks for heading/spacing/native controls, theme aliases, explicit isolation grids, absent optional error prop omitted for exactOptionalPropertyTypes, mechanical formatter/import ordering. ApprovedCG-D2bytes retained at review/preserved/CG-D2-approved.tar.gz; neutral diagram role correction is accessibility-only. No direction was materially changed. Original region archives retain pre-integration bytes; no independent output was overwritten and represented as untouched.

Culture failure Callout text contrast was4.45:1 due neutral tint over vermilion. Consumer fixture foreground corrected, before matrix preserved and18replays pass. Audit-report pre caused outside-product overflow; wrapping fixed in harness. These bounded setup/integration repairs do not hide shared capability gaps.

### Goal5 owner checkpoint

Preview http://127.0.0.1:43427/experiments/surface-study/review/ from existing server. Current candidate I1, source0.5.0/d3e0e83, blueprintsB1, regionR1archives and exact integration/evidence pins in review/goal5.json. Findings/API/slices in review/findings.md; coverageCG-C3. Human preference/coherence/task-clarity review pending.

Recommendation: approve boundedGoal6 F1Operations title/count fix, F2Commerce caption backing/contrast proof, G1newSelect, G2newCheckbox, G4newRadioGroup and G5Buttondurationtoken. Reuse each new shared API in two actual contrasting contexts and perform fresh-region transfer using public docs/imports. Do not implement deferredTabs/Table/Split, production services, adoption, release or milestone changes.

Owner options: approve this candidate/correction scope, request changes, or reject. Await direct response; no Goal6 work. On approval record exact reviewed revisions and resume approved slices automatically, regression/transfer/closeout included. Approval never establishes independent authorship or missing AT/preference evidence.

Final review-board visual QA found an invalid raw full-page Commerce capture (unstyled thumbnail), while live DOM/style/axe/task evidence remained correct. Replaced comparison thumbnails with newly captured, individually inspected native live overviews for all three apps; live-overviews.json records actual1440CSSpx and intended colors/grid tracks. Raw full-page files remain diagnostic history; use *-overview-1440.png for visual identity review. This was screenshot evidence repair, no application/source behavior change. Final board reloaded and checked before owner handoff.

Native overview/control captures now also cover actual390/768CSSpx for all three apps; live-narrow.json verifies measured dimensions and no overflow. Width-evidence links point to these inspected native capture routes rather than raw full-page captures. Browser viewport overrides applied only to active visible tab; a failed hidden-tab capture attempt was detected by measured1440px and replaced, never counted as narrow proof.


## Goal 5 I2 — owner changes requested and revised

Owner supplied screenshots of pill dialog clipping, indistinguishable disabled Chalk and product-price baseline mismatch. Requested all-surface state/interaction/geometry/media/motion/performance audit. This authorizes checkpoint revision, not blanket approval of prior shared-component scope. I1 review documents preserved before edits; original integration and regions retained.

I2 details, ownership, assertion Red/Green, state coverage, review-only gate refusal and proof limits: `review/I2-review.md`. Source core unchanged, catalog15.39tests pass; production build and90layout cases pass.48automated scans,6keyboard error/retry journeys and6final focus recoveries; finite motion and responsive credited stock imagery. Production main entry464030bytes versus1407732I1. Same-session work; universal hardware/accessibility/independent-review claims remain withheld.

Current candidate `review/integration-I2.tar.gz`, pins `review/goal5.json`, board `review/index.html`. F1/F2 resolved; proposed shared additions remain owner-gated. Next action: owner approve I2 and bounded shared scope, request changes, or reject. No commit/push/release/adoption or milestone mutation.


## Goal 5 I3 — overlay audit requested

Owner supplied Bag review screenshot and requested audit of all popovers. Actual floating inventory:2Dialog instances,2native product selects, no study Menu/Tooltip; inline disclosures inventoried separately. Shared Menu/Tooltip reviewed at source level. Overlay direction and classified findings in review/I3-overlay-audit.md. Revised both dialogs through public composition, detail/total hierarchy, closeX and distinct paper/ticket elevation. Fixed inherited footer gap, cache versioning and long title mismatch after observable Red evidence.43tests pass;16size cases +8variants, no overflow/recorded axe violations, contrast incomplete explicitly retained and authored pairs checked. Goal6 shared work remains held. Prior I2archive and checkpoint documents preserved. No core changes, commit/push or adoption.


## Goal 5 I4 — appropriate motion across surfaces

Owner requested coherent transitions across Commerce/Operations/Culture. Preserve identity through control/content/overlay timing roles, restore control color feedback, add finite content/disclosure/feedback/dialog motion and accessible preview reduction.46tests pass after3assertion Red;12normal/reduced task journeys at390/1440,36state/mode checks,6final primary replays and6ready accessibility scans pass within measured scope. Finallocal frame sampler has p958.8–9.3ms; no hardware guarantee. Details/limits: review/I4-motion-review.md. I3snapshot retained, core unchanged, Goal6held pending ownerreview.


## Goal 5 approval / Goal 6 start

Owner approved I4and explicitly authorized Goal6shared controls, extensible modal styling and motion across surfaces. Exact reviewed manifest SHA and approved scope: review/goal5-approval.json. Resume sequential shared delivery, contrasting-context integration, regression, fresh-region transfer and closing result/adoption preparation. Core edits now authorized; no commits/push/releases/adoption. Original source remains preserved in source archive; future source checks must distinguish baseline archive from authorized final source.


## Goal 6 / G6 delivery

Approved shared Select/Checkbox/RadioGroup shipped in maintained source with public exports, tokens/anatomy, typed controlled APIs, labels/errors/disabled/ref/keyboard contracts, tests/stories/docs and two contrasting existing integrations each. Dialog gains neutral sections and material/elevation/type/motion tokens; Button/popup timing and Menu/Tooltip portal hosts extensible. Fresh AssignmentPreferences region tested public docs/APIs, with shared text inheritance and dark radio border repairs, consumer grid repair and cache fingerprinting recorded. Final result, evidence limits and concrete confirmed Bezl Task trial: results.md / adoption.md. No adoption, milestone mutation, commit, push or release performed.
