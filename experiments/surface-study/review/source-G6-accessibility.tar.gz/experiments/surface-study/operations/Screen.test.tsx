import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { OperationsScreen } from "./Screen";

describe("Operations fixture journey", () => {
  it("assigns selected tasks and announces exact count", async () => {
    render(<OperationsScreen />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    fireEvent.click(screen.getByLabelText("Select R-108"));
    expect(screen.getByRole("button", { name: "Assign selected to Mira" })).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Assign selected to Mira" }));
    expect(screen.getByRole("status")).toHaveTextContent("Assigned 2 tasks to Mira.");
    expect(screen.getByRole("status")).toHaveFocus();
    expect(screen.getByLabelText("Select R-104")).not.toBeChecked();
  });
  it("reports hidden selection rather than silently dropping scope", async () => {
    render(<OperationsScreen />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    fireEvent.change(screen.getByLabelText("Search tasks"), { target: { value: "scanner" } });
    expect(screen.getByText("1 selected · 1 hidden by filters")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "Assign selected to Mira" }));
    expect(screen.getByRole("status")).toHaveTextContent("Assigned 1 task to Mira.");
  });
  it("selects visible eligible tasks and exposes mixed state", async () => {
    render(<OperationsScreen />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    expect(screen.getByLabelText("Select all visible eligible tasks")).toHaveAttribute(
      "aria-checked",
      "mixed",
    );
    fireEvent.click(screen.getByLabelText("Select all visible eligible tasks"));
    expect(screen.getByText("3 selected · 0 hidden by filters")).toBeVisible();
    fireEvent.click(screen.getByLabelText("Select all visible eligible tasks"));
    expect(screen.getByRole("button", { name: "Assign selected to Mira" })).toBeDisabled();
  });
  it("never selects a locked task", async () => {
    render(<OperationsScreen />);
    await userEvent.click(screen.getByRole("combobox", { name: "Task status" }));
    await userEvent.click(await screen.findByRole("option", { name: "All open tasks" }));
    expect(screen.getByLabelText("Select R-120")).toBeDisabled();
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("All open tasks 12");
    fireEvent.click(screen.getByLabelText("Select all visible eligible tasks"));
    expect(screen.getByText("11 selected · 0 hidden by filters")).toBeVisible();
  });
  it("keeps selection after failure; retry assigns only once", async () => {
    render(<OperationsScreen scenario="action-error" />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    fireEvent.click(screen.getByRole("button", { name: "Assign selected to Mira" }));
    expect(screen.getByRole("alert")).toHaveTextContent("Assignment failed");
    expect(screen.getByLabelText("Select R-104")).toBeChecked();
    fireEvent.click(screen.getByRole("button", { name: "Assign selected to Mira" }));
    expect(screen.getByRole("status")).toHaveTextContent("Assigned 1 task to Mira.");
    expect(screen.getByRole("button", { name: "Assign selected to Mira" })).toBeDisabled();
  });
  it("inspects another task without changing checkbox selection", async () => {
    render(<OperationsScreen />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    fireEvent.click(screen.getByRole("button", { name: /^Inspect R-108:/ }));
    expect(screen.getByRole("complementary", { name: "Task inspector" })).toHaveTextContent(
      "Replace scanner battery",
    );
    expect(screen.getByLabelText("Select R-104")).toBeChecked();
  });
  it("shows empty search and provides clear recovery", async () => {
    render(<OperationsScreen />);
    fireEvent.change(screen.getByLabelText("Search tasks"), { target: { value: "no such task" } });
    expect(screen.getByText("No matching tasks.")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "Clear search" }));
    expect(screen.getByLabelText("Select R-104")).toBeVisible();
  });
  it.each(["loading", "empty", "error"] as const)("recovers %s fixture", (scenario) => {
    render(<OperationsScreen scenario={scenario} />);
    fireEvent.click(
      screen.getByRole("button", {
        name:
          scenario === "loading"
            ? "Show loaded preview"
            : scenario === "empty"
              ? "Explore sample data"
              : "Try again",
      }),
    );
    expect(screen.getByLabelText("Select R-104")).toBeVisible();
  });
  it("explains disabled bulk actions until eligible selection exists", async () => {
    render(<OperationsScreen />);
    expect(screen.getByText("Select an unlocked task to enable assignment.")).toBeVisible();
    fireEvent.click(screen.getByLabelText("Select R-104"));
    expect(
      screen.queryByText("Select an unlocked task to enable assignment."),
    ).not.toBeInTheDocument();
  });
  it("clears obsolete assignment error when selection is cleared", async () => {
    render(<OperationsScreen scenario="action-error" />);
    fireEvent.click(screen.getByLabelText("Select R-104"));
    fireEvent.click(screen.getByRole("button", { name: "Assign selected to Mira" }));
    expect(screen.getByRole("alert")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "Clear selection" }));
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });
});
