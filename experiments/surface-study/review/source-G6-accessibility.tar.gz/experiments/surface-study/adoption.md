# Portable adoption and bounded consumer trial / G6

> **G6-A follow-up supersedes readiness below:** accessibility defects fixed and independently re-reviewed; 232 normal/reduced browser tests, 10 targeted forced-color checks and 48 study tests pass. VoiceOver sign-off remains pending by owner instruction. Formal exact-head gate remains blocked without a committed review round. Bezl trial held. See [follow-up and current obligations](review/accessibility-followup.md). Original G6 evidence below is historical.


## Portable recipe

Supported source host: React/react-dom >=19, TypeScript/JSX, Base UI 1.9.0 via `@kbui/react`, browser DOM and CSS custom properties. Verified here with React 19.3.1 and Vite/Bun; SSR/hydration, native adapters and other engines remain untested. See maintained [installation](../../docs/guides/using-kbui.md), [forms/overlays](../../docs/guides/forms-and-overlays.md) and [tokens](../../docs/tokens.md).

G6 is unreleased source after baseline 0.5.0. Do not install published 0.5.0 expecting these APIs. Starting input is the exact source packet and hashes in [goal6.json](review/goal6.json), based on d3e0e83. For a separately authorized local trial, build that snapshot with `bun run build`, then install all three matching local workspace packages or locally packed tarballs together. The guide's normal release-install command remains for released versions; no release was produced here. Version numbers alone cannot identify these uncommitted source additions.

Load `@kbui/css/styles.css` once before product styles. It includes tokens; optional `@kbui/tokens` exports typed variable names. Import public components from `@kbui/react`. Use semantic tokens and documented component tokens on a theme wrapper; remap aliases where declared. Supply that wrapper's ref to Dialog/Menu/Tooltip `container`; Select inherits its field root by default. Keep portal hosts outside clipping/transformed ancestors; verify overlays inside the actual host. Product data, validation, persistence, layouts and identity remain in the consumer. Do not copy shared component internals or add `.kb-*` specificity patches.

Runnable local example: [AssignmentPreferences](transfer/AssignmentPreferences.tsx), [preview](transfer/index.html), and its behavior test. Build study via `bun experiments/surface-study/runtime/build.ts`; serve the worktree root with a local HTTP server, then open `/experiments/surface-study/transfer/`. This proves public-import source composition, not a clean external package install. Root pack checks validate tarball contents; new-version external installation remains unperformed.

Validation recipe: matching package versions via documented `@kbui/react/check-versions`, consumer type/lint/unit/browser/build gates, light/dark and theme-on/off, 390/768/1440 reflow, long/empty/error/disabled/mixed states, keyboard selection and Escape/focus return, actual reduced-motion media, manual screen reader/forced-color checks, actual target WebView if native. Record workarounds and integration time, not just screenshots.

## Concrete trial: Bezl Task screen

**Target confirmed as existing consumer; trial awaiting separate authorization and package prerequisites.** Repository `/Users/khallil/proj/bezl`, observed HEAD `9b2121a6f16d5710c611597eb16bf94db4e3f560`; no clean-tree or remote freshness claim. Its package manifest installs kbui React/CSS/tokens 0.4.0 together; React 19.3.1, Tauri 2.12.4. README identifies `src/ui/task` as an interim Task screen; `docs/ui-styling.md` specifies nested `AppTheme`, `usePortalRoot`, light/dark + theme-on/off, glass panels and reduced motion. The later M5 task journey replaces this screen: confirm this bounded interim-screen trial is still useful before implementation.

Purpose: inspect live-worker task status and review/cancel a stop action while retaining Bezl's glass, Geist/Geist Mono and native-window identity. This tests a real desktop theme host, overlay semantics, offline assets, status-rich content and theme invariance beyond the study's paper/editorial fixtures. This selection does not make Bezl the design-system boundary.

Starting inputs: G6 exact packet, [results](results.md), maintained component guide, existing Bezl `docs/ui-styling.md`, `src/ui/theme` contracts and `Task.browser.test.tsx`. Read target instructions before work. No target source was changed or checks run there.

Bounded scope: upgrade the three kbui packages together to a separately prepared matching trial build; adapt existing Task stop dialog to public material/section/motion tokens and the existing portal host. Preserve current workflow, state model, copy and task graph. Exercise idle/running/blocked/longContent samples, stop dialog open/cancel, keyboard return, light/dark, theme on/off and reduced motion. Do not add worker/model preferences solely to exercise new controls; do not invoke real workers or change stop/domain authority, Tauri IPC, graph animation or task-journey architecture.

Prerequisites: owner chooses timing relative to M5; trial snapshot is committed/released or locally packaged through an authorized workflow; reconcile 0.4.0→current source compatibility; verify package provenance/version matching. Resolve any actual theme-host/scrolling failure before expanding scope. New controls and nested Select-in-dialog are available for later demonstrated needs, not required in this trial. Manual AT and Tauri WebView checks remain trial obligations.

Acceptance: same observable Task states and stop/cancel behavior, focus returns to stop trigger, no action sent on cancel, text/background/geometry retain identity, theme toggling changes values without changing behavior or structure, no direct shared-selector styling, no overflow at 390/768/1440, no unresolved browser accessibility violations and every incomplete result adjudicated explicitly. Existing target scripts, **proposed for the trial, not run here**: `bun run check`, `bun run build`; its browser suite covers light/dark and theme-on/off. Add focused tests before any changed behavior and inspect actual Tauri preview manually with fixture data. Do not infer native-host success from Chromium.

Learning to record: package/API migration cost and elapsed time; missing tokens/parts; clipping/stacking/focus repairs; theme-specific overrides; custom composition count; user-visible regressions; WebView differences. Compare against original 0.4.0 Task screenshots/tests and G6 control/modal baseline.

Reversibility: isolate trial on a named worktree/branch; retain package lock/manifest and Task/theme changes together. Restore original package pins and Task composition if acceptance fails; no data migration or live-worker operation is part of trial. Prepared handoff does not execute adoption or mark M1 complete.
