import type { StorybookConfig } from "@storybook/react-vite";

const config: StorybookConfig = {
  framework: "@storybook/react-vite",
  stories: [
    "../docs/**/*.mdx",
    "../../../packages/react/src/**/*.stories.tsx",
    "../stories/**/*.stories.tsx",
  ],
  staticDirs: [{ from: "../../../experiments/surface-study/assets", to: "/assets" }],
  addons: ["@storybook/addon-docs", "@storybook/addon-a11y", "@storybook/addon-vitest"],
};

export default config;
