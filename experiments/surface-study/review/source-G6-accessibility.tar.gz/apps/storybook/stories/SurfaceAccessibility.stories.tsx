import type { Meta, StoryObj } from "@storybook/react-vite";
import { expect, userEvent, waitFor, within } from "storybook/test";
import { page } from "vitest/browser";
import commerceCSS from "../../../experiments/surface-study/commerce/blueprint/theme.css?inline";
import { CommerceScreen } from "../../../experiments/surface-study/commerce/Screen";
import cultureCSS from "../../../experiments/surface-study/culture/blueprint/theme.css?inline";
import { CultureScreen } from "../../../experiments/surface-study/culture/Screen";
import operationsCSS from "../../../experiments/surface-study/operations/blueprint/theme.css?inline";
import { OperationsScreen } from "../../../experiments/surface-study/operations/Screen";
import surfaceCSS from "../../../experiments/surface-study/runtime/ui.css?inline";
import { visualTextProof } from "../../../experiments/surface-study/runtime/visualTextProof";
import { AssignmentPreferences } from "../../../experiments/surface-study/transfer/AssignmentPreferences";

const meta = {
  title: "Validation/Surface accessibility",
  parameters: { layout: "fullscreen" },
  decorators: [
    (Story) => (
      <>
        <style>{commerceCSS + operationsCSS + cultureCSS + surfaceCSS}</style>
        <Story />
      </>
    ),
  ],
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;
const shell = (child: React.ReactNode) => <main className="app-main">{child}</main>;
async function modalWitness(trigger: HTMLElement, width: number) {
  await page.viewport(width, 900);
  await userEvent.click(trigger);
  const dialog = await within(document.body).findByRole("dialog");
  await waitFor(() => expect(dialog).not.toHaveAttribute("data-starting-style"));
  await waitFor(() => expect(getComputedStyle(dialog).opacity).toBe("1"));
  for (const note of dialog.querySelectorAll<HTMLElement>(".overlay-note,.kb-dialog-description")) {
    note.scrollIntoView({ block: "nearest" });
    await waitFor(() => expect(visualTextProof(note)).toMatchObject({ pass: true }));
  }
  for (let i = 0; i < 8; i++) {
    await userEvent.tab();
    await waitFor(() => expect(dialog).toContainElement(document.activeElement as HTMLElement));
  }
  await userEvent.keyboard("{Escape}");
  await waitFor(() => expect(trigger).toHaveFocus());
}
export const SurfaceCommerce: Story = {
  render: () => shell(<CommerceScreen />),
  play: async ({ canvasElement }) =>
    modalWitness(within(canvasElement).getByRole("button", { name: /Add to bag/ }), 390),
};
export const SurfaceCommerceWide: Story = {
  ...SurfaceCommerce,
  play: async ({ canvasElement }) =>
    modalWitness(within(canvasElement).getByRole("button", { name: /Add to bag/ }), 1440),
};
export const SurfaceCulture: Story = {
  render: () => shell(<CultureScreen />),
  play: async ({ canvasElement }) =>
    modalWitness(within(canvasElement).getByRole("button", { name: "Review reservation" }), 390),
};
export const SurfaceCultureWide: Story = {
  ...SurfaceCulture,
  play: async ({ canvasElement }) =>
    modalWitness(within(canvasElement).getByRole("button", { name: "Review reservation" }), 1440),
};
export const SurfacePreferences: Story = {
  render: () => shell(<AssignmentPreferences />),
  play: async ({ canvasElement }) =>
    modalWitness(within(canvasElement).getByRole("button", { name: "Review preferences" }), 390),
};
export const SurfaceOperations: Story = {
  render: () => shell(<OperationsScreen scenario="action-error" />),
  play: async ({ canvasElement }) => {
    await page.viewport(390, 900);
    const c = within(canvasElement);
    await userEvent.click(c.getByRole("combobox", { name: "Task status" }));
    await userEvent.click(
      await within(document.body).findByRole("option", { name: "All open tasks" }),
    );
    await userEvent.click(c.getByRole("checkbox", { name: "Select R-104" }));
    await expect(c.getByRole("checkbox", { name: "Select R-120" })).toBeDisabled();
    await userEvent.click(c.getByRole("button", { name: "Assign selected to Mira" }));
    await expect(c.getByRole("alert")).toHaveTextContent("Assignment failed");
    await userEvent.click(c.getByRole("button", { name: "Assign selected to Mira" }));
    await expect(c.getByRole("status")).toHaveTextContent("Assigned 1 task to Mira.");
  },
};
export const WitnessRejectsFailures: Story = {
  render: () => (
    <div>
      <p data-testid="low" style={{ color: "#aaa", background: "#fff" }}>
        Low contrast
      </p>
      <p data-testid="alpha-fg" style={{ color: "rgba(0,0,0,.01)", background: "#fff" }}>
        Transparent ink
      </p>
      <p data-testid="alpha-bg" style={{ color: "#000", background: "rgba(255,255,255,.3)" }}>
        Translucent paper
      </p>
      <div style={{ opacity: 0.1 }}>
        <p data-testid="ancestor" style={{ color: "#000", background: "#fff" }}>
          Faded context
        </p>
      </div>
      <p data-testid="nested" style={{ color: "#000", background: "#fff" }}>
        <span style={{ color: "#fff" }}>Different child ink</span>
      </p>
      <div style={{ position: "relative" }}>
        <p data-testid="covered" style={{ color: "#000", background: "#fff" }}>
          Covered note
        </p>
        <div style={{ position: "absolute", inset: 0, background: "#000" }} aria-hidden="true" />
      </div>
    </div>
  ),
  play: async ({ canvasElement }) => {
    for (const id of ["alpha-fg", "alpha-bg", "ancestor", "nested"])
      await expect(visualTextProof(within(canvasElement).getByTestId(id)).pass).toBe(false);
    await expect(visualTextProof(within(canvasElement).getByTestId("low")).pass).toBe(false);
    await expect(visualTextProof(within(canvasElement).getByTestId("covered")).pass).toBe(false);
  },
  parameters: { a11y: { disable: true } },
};
